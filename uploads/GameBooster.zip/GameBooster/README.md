# Game Booster

Lightweight Android Game Booster — very small APK, no root required.

## Features
- **One-tap RAM Boost** — kills background processes via ActivityManager
- **Performance Modes** — Balanced / Performance / Battery Saver
- **Game Launcher** — auto-detects games (CATEGORY_GAME + ApplicationInfo.CATEGORY_GAME fallback)
- **Quick Settings Tile** — instant boost from notification shade
- **Do Not Disturb** — on-boost DND with graceful permission handling
- **Settings** — mode selector, DND toggle, auto-boost preference

## Build locally

### Debug
```bash
./gradlew assembleDebug
```

### Release (signed)
```bash
export KEYSTORE_PATH=/path/to/release.jks
export STORE_PASSWORD=yourStorePass
export KEY_ALIAS=yourAlias
export KEY_PASSWORD=yourKeyPass
./gradlew assembleRelease
```

## CI — GitHub Actions

The workflow at `.github/workflows/build.yml` builds **both** Debug and Release APKs automatically.

### One-time keystore setup

```bash
keytool -genkey -v -keystore release.jks \
  -alias gamebooster -keyalg RSA -keysize 2048 \
  -validity 10000

# Encode for GitHub secret
base64 -w 0 release.jks      # Linux
base64 release.jks             # macOS
```

### Required repository secrets

| Secret | Value |
|--------|-------|
| `KEYSTORE_BASE64` | Output of the base64 command above |
| `STORE_PASSWORD`  | Password chosen during keytool |
| `KEY_ALIAS`       | Alias chosen during keytool (e.g. `gamebooster`) |
| `KEY_PASSWORD`    | Key password chosen during keytool |

**Settings → Secrets and variables → Actions → New repository secret**

### Artifacts produced per run

| Artifact | Description |
|----------|-------------|
| `GameBooster-debug-buildN`   | Debug APK — always built, no secrets needed |
| `GameBooster-release-buildN` | Signed, minified, per-ABI release APK |

## Permissions

| Permission | Purpose |
|-----------|---------|
| `KILL_BACKGROUND_PROCESSES` | RAM cleanup on boost |
| `ACCESS_NOTIFICATION_POLICY` | DND toggle |

Both are optional — app degrades gracefully if denied.

## APK size optimizations
- R8 full-mode + resource shrinking (release)
- ABI splits: `armeabi-v7a`, `arm64-v8a`, `x86` — no universal APK
- Zero third-party libraries beyond AndroidX + Material Components
- All icons are vector drawables
- No unused assets, no Compose, no kapt
