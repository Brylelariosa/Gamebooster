package com.gamebooster

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable

data class GameInfo(val name: String, val packageName: String, val icon: Drawable)

class GameDetector(private val context: Context) {

    fun getInstalledGames(): List<GameInfo> {
        val pm = context.packageManager
        val games = mutableListOf<GameInfo>()

        // Primary: CATEGORY_GAME intent filter
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_GAME)
        try {
            for (ri in pm.queryIntentActivities(intent, 0)) {
                val ai = ri.activityInfo.applicationInfo
                try {
                    games += GameInfo(
                        pm.getApplicationLabel(ai).toString(),
                        ai.packageName,
                        pm.getApplicationIcon(ai)
                    )
                } catch (e: Exception) { /* skip */ }
            }
        } catch (e: Exception) { /* skip */ }

        // Fallback: ApplicationInfo.CATEGORY_GAME flag
        if (games.isEmpty()) {
            try {
                for (ai in pm.getInstalledApplications(PackageManager.GET_META_DATA)) {
                    if (ai.category == ApplicationInfo.CATEGORY_GAME) {
                        try {
                            games += GameInfo(
                                pm.getApplicationLabel(ai).toString(),
                                ai.packageName,
                                pm.getApplicationIcon(ai)
                            )
                        } catch (e: Exception) { /* skip */ }
                    }
                }
            } catch (e: Exception) { /* skip */ }
        }

        return games.distinctBy { it.packageName }.sortedBy { it.name }
    }

    fun launchGame(packageName: String) {
        try {
            val launch = context.packageManager.getLaunchIntentForPackage(packageName)
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launch)
            }
        } catch (e: Exception) { /* graceful */ }
    }
}
