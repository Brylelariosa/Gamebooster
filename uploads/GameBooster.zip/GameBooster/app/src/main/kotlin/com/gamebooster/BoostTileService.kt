package com.gamebooster

import android.content.Context
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class BoostTileService : TileService() {

    override fun onTileAdded()      { super.onTileAdded();      setTile(false) }
    override fun onStartListening() { super.onStartListening(); setTile(false) }

    override fun onClick() {
        super.onClick()
        setTile(true)
        val ctx   = applicationContext
        val prefs = ctx.getSharedPreferences("gb_prefs", Context.MODE_PRIVATE)
        val mode  = PerformanceMode.valueOf(prefs.getString("perf_mode","BALANCED") ?: "BALANCED")
        val mgr   = BoostManager(ctx)
        Thread {
            mgr.boost(mode)
            if (prefs.getBoolean("dnd_enabled", false)) mgr.enableDnd(true)
            qsTile?.apply { state = Tile.STATE_INACTIVE; updateTile() }
        }.start()
    }

    private fun setTile(active: Boolean) {
        qsTile?.apply {
            state = if (active) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            updateTile()
        }
    }
}
