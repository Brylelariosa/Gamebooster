package com.gamebooster

import android.app.ActivityManager
import android.app.NotificationManager
import android.content.Context

enum class PerformanceMode { BALANCED, PERFORMANCE, BATTERY_SAVER }

data class BoostResult(val processesAffected: Int, val freeMemMB: Long)
data class MemStats(val totalMB: Long, val freeMB: Long, val usedMB: Long)

class BoostManager(private val context: Context) {

    private val activityManager =
        context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private val notificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    fun boost(mode: PerformanceMode): BoostResult {
        val killed = when (mode) {
            PerformanceMode.PERFORMANCE -> killBackgroundProcesses(aggressive = true)
            PerformanceMode.BALANCED    -> killBackgroundProcesses(aggressive = false)
            PerformanceMode.BATTERY_SAVER -> killBackgroundProcesses(aggressive = false)
        }
        val memInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memInfo)
        return BoostResult(killed, memInfo.availMem / (1024L * 1024L))
    }

    private fun killBackgroundProcesses(aggressive: Boolean): Int {
        var count = 0
        try {
            val myPkg = context.packageName
            val processes = activityManager.runningAppProcesses ?: return 0
            val threshold = if (aggressive)
                ActivityManager.RunningAppProcessInfo.IMPORTANCE_VISIBLE
            else
                ActivityManager.RunningAppProcessInfo.IMPORTANCE_SERVICE
            for (proc in processes) {
                if (proc.importance >= threshold && proc.processName != myPkg) {
                    try {
                        activityManager.killBackgroundProcesses(proc.processName)
                        count++
                    } catch (e: Exception) { /* best-effort */ }
                }
            }
        } catch (e: Exception) { /* graceful */ }
        return count
    }

    fun enableDnd(enable: Boolean): Boolean {
        if (!notificationManager.isNotificationPolicyAccessGranted) return false
        return try {
            notificationManager.setInterruptionFilter(
                if (enable) NotificationManager.INTERRUPTION_FILTER_NONE
                else        NotificationManager.INTERRUPTION_FILTER_ALL
            )
            true
        } catch (e: Exception) { false }
    }

    fun isDndPermissionGranted(): Boolean =
        notificationManager.isNotificationPolicyAccessGranted

    fun getMemoryInfo(): MemStats {
        val info = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(info)
        return MemStats(
            totalMB = info.totalMem / (1024L * 1024L),
            freeMB  = info.availMem / (1024L * 1024L),
            usedMB  = (info.totalMem - info.availMem) / (1024L * 1024L)
        )
    }
}
