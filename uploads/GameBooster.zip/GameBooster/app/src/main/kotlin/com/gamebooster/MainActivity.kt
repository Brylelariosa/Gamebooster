package com.gamebooster

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {

    private lateinit var boostManager: BoostManager
    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        boostManager = BoostManager(this)
        prefs = getSharedPreferences("gb_prefs", Context.MODE_PRIVATE)

        updateRam()

        findViewById<MaterialButton>(R.id.btn_boost).setOnClickListener { doBoost() }
        findViewById<MaterialButton>(R.id.btn_games).setOnClickListener {
            startActivity(Intent(this, GameLauncherActivity::class.java))
        }
        findViewById<MaterialButton>(R.id.btn_settings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        updateRam()
    }

    private fun updateRam() {
        val s = boostManager.getMemoryInfo()
        findViewById<TextView>(R.id.tv_free_ram).text = getString(R.string.ram_free, s.freeMB)
        findViewById<TextView>(R.id.tv_total_ram).text = getString(R.string.ram_total, s.totalMB)
        val pct = if (s.totalMB > 0) ((s.usedMB * 100L) / s.totalMB).toInt() else 0
        findViewById<ProgressBar>(R.id.pb_ram).progress = pct
    }

    private fun doBoost() {
        val btn = findViewById<MaterialButton>(R.id.btn_boost)
        val tv  = findViewById<TextView>(R.id.tv_status)
        btn.isEnabled = false
        tv.text = getString(R.string.boosting)

        val mode = PerformanceMode.valueOf(
            prefs.getString("perf_mode", "BALANCED") ?: "BALANCED"
        )

        Thread {
            val result = boostManager.boost(mode)

            // Apply DND if enabled
            if (prefs.getBoolean("dnd_enabled", false)) {
                boostManager.enableDnd(true)
            }

            runOnUiThread {
                updateRam()
                tv.text = getString(R.string.boost_done, result.freeMemMB.toInt())
                btn.isEnabled = true
            }
        }.start()
    }
}
