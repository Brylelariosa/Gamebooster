package com.gamebooster

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class GameLauncherActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game_launcher)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = getString(R.string.games)

        val listView = findViewById<ListView>(R.id.lv_games)
        val tvEmpty  = findViewById<TextView>(R.id.tv_empty)

        Thread {
            val games = GameDetector(this).getInstalledGames()
            runOnUiThread {
                if (games.isEmpty()) {
                    tvEmpty.visibility = View.VISIBLE
                    listView.visibility = View.GONE
                } else {
                    tvEmpty.visibility = View.GONE
                    listView.visibility = View.VISIBLE
                    listView.adapter = GameAdapter(this, games)
                    listView.setOnItemClickListener { _, _, pos, _ ->
                        GameDetector(this).launchGame(games[pos].packageName)
                    }
                }
            }
        }.start()
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed(); return true
    }
}

private class GameAdapter(
    ctx: Context,
    private val items: List<GameInfo>
) : ArrayAdapter<GameInfo>(ctx, R.layout.item_game, items) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val v = convertView
            ?: LayoutInflater.from(context).inflate(R.layout.item_game, parent, false)
        v.findViewById<ImageView>(R.id.iv_icon).setImageDrawable(items[position].icon)
        v.findViewById<TextView>(R.id.tv_name).text = items[position].name
        return v
    }
}
