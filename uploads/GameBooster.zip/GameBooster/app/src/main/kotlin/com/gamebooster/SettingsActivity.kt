package com.gamebooster

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat

class SettingsActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var boostMgr: BoostManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = getString(R.string.settings)

        prefs    = getSharedPreferences("gb_prefs", Context.MODE_PRIVATE)
        boostMgr = BoostManager(this)

        setupMode()
        setupDnd()
        setupAutoBoost()
    }

    override fun onResume() {
        super.onResume()
        refreshDndStatus()
    }

    private fun setupMode() {
        val spinner = findViewById<Spinner>(R.id.spinner_mode)
        val labels  = arrayOf(
            getString(R.string.mode_balanced),
            getString(R.string.mode_performance),
            getString(R.string.mode_battery)
        )
        spinner.adapter = ArrayAdapter(this,
            android.R.layout.simple_spinner_dropdown_item, labels)

        spinner.setSelection(when (prefs.getString("perf_mode","BALANCED")) {
            "PERFORMANCE"  -> 1
            "BATTERY_SAVER"-> 2
            else           -> 0
        })

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                prefs.edit().putString("perf_mode", when(pos) {
                    1 -> "PERFORMANCE"; 2 -> "BATTERY_SAVER"; else -> "BALANCED"
                }).apply()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    private fun setupDnd() {
        val sw = findViewById<SwitchCompat>(R.id.switch_dnd)
        sw.isChecked = prefs.getBoolean("dnd_enabled", false)
        sw.setOnCheckedChangeListener { _, checked ->
            if (checked && !boostMgr.isDndPermissionGranted()) {
                sw.isChecked = false
                startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            } else {
                prefs.edit().putBoolean("dnd_enabled", checked).apply()
            }
        }
    }

    private fun setupAutoBoost() {
        val sw = findViewById<SwitchCompat>(R.id.switch_auto)
        sw.isChecked = prefs.getBoolean("auto_boost", false)
        sw.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("auto_boost", checked).apply()
        }
    }

    private fun refreshDndStatus() {
        val granted = boostMgr.isDndPermissionGranted()
        findViewById<TextView>(R.id.tv_dnd_status).text =
            getString(if (granted) R.string.perm_granted else R.string.perm_missing)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed(); return true
    }
}
