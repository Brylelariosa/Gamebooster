-keep class com.gamebooster.BoostTileService { *; }
-keep class com.gamebooster.BoostManager { *; }
-keep enum com.gamebooster.PerformanceMode { *; }
-keepclassmembers class * implements android.os.Parcelable {
    static ** CREATOR;
}
-keepclassmembers class **.R$* {
    public static <fields>;
}
