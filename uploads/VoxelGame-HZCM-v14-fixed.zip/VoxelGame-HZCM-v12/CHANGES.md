# HZCM v4 — Engineering Change Log (v12 → v13)

## Fixes — Chunk loading stall at render distance 8 and above

These fixes address all six requirements from the RD≥8 streaming failure report.

---

### Fix 1 · `LockFreeJobQueue.h` — Queue capacity 1024 → 4096 (primary bottleneck)

**Root cause:** At RD=8, each completed `CHUNK_BUILD` triggers `workerNeighbourFlush`
which enqueues up to 16 `CLUSTER_REBUILD` jobs (4 cardinal neighbours × 4 clusters).
With ~361 primary jobs at RD=8, peak burst is ≈2527 concurrent jobs — well above the
1024-slot ring.  When the ring saturated, secondary jobs were silently dropped,
causing permanent border seams and missing neighbour rebuilds.

**Fix A:** Increase `JOB_RING_CAPACITY` 1024 → **4096** (4× capacity, still a power
of 2, occupies 256 KB — acceptable for mobile L2/L3).  4096 absorbs the full burst
up to RD≈12 with zero drops; at higher RD the submission budget limiter keeps the
queue from filling.

**Fix B:** Add `isFull()` and `approximateFree()` helper methods to `MpmcJobRing`
so the submission loop can make tighter capacity decisions without computing the
difference externally.

```cpp
// Before:
static constexpr uint32_t JOB_RING_CAPACITY = 1024;

// After:
static constexpr uint32_t JOB_RING_CAPACITY = 4096;
```

---

### Fix 2 · `World.cpp` — Submission budget formula: replace integer-division stall

**Root cause:** The old `maxNew` formula used integer division:

```cpp
max(8, rebuildBudget * max(1, effectiveRadius / 8))
```

C++ integer division truncates: `effectiveRadius / 8 = 1` for RD=8..15.
With `rebuildBudget=8` (COOL state), this gives `maxNew = max(8, 8) = 8` for ALL
render distances 8–15 — the same rate as RD=7 (289 chunks) even though RD=15 has
961 chunks (3.3× more).  At RD=15, submitting only 8/frame takes 120 frames (~2s)
before all chunks are even queued, and the queue saturates from secondary jobs
in the meantime.

**Fix:** New formula targets loading one outer-ring shell in ~4 frames:

```cpp
// Outer ring shell has ~8×R chunks → budget = 8R / 4 = 2R
int baseNew = max(8, 2 * effectiveRadius);
// Scale by thermal state (8/4/2/1 for COOL/WARM/HOT/CRITICAL)
baseNew = max(8, baseNew * thermalBudget / 8);
```

Results at COOL:
- RD=8:  `max(8, 16)` = **16**/frame  (was 8; 361 chunks queued in ~23 frames)
- RD=12: `max(8, 24)` = **24**/frame  (was 8; 729 chunks in ~30 frames)
- RD=16: `max(8, 32)` = **32**/frame  (was 16; 1225 chunks in ~38 frames)
- RD=20: `max(8, 40)` = **40**/frame

Headroom cap now uses `approximateFree()` with 128-slot headroom (was 32) to leave
more room for the secondary jobs that workers enqueue during the submission window.

---

### Fix 3 · `World.cpp` — Retry queue replaces silent job drop

**Root cause:** `enqueueChunkBuild`, `enqueueClusterRebuild`, and
`enqueueNeighbourFlush` each contained:

```cpp
if (!m_jobQueue.push(job))
    LOGE("... dropped");   // ← job is gone forever
```

When the queue filled from secondary job bursts, border-correction
`CLUSTER_REBUILD` jobs were permanently lost.  The seam between two chunks was
never fixed — visible as a permanent 1-voxel-wide gap or wrong-face stripe.

**Fix:** All three enqueue helpers now fall through to a `m_retryQueue`
(`std::vector<WorldJob>` under `m_retryMtx`) on push failure.  A new
`drainRetryQueue()` method is called at the TOP of every `update()` — before any
new chunk submissions — and attempts to push deferred jobs back into the ring:

```cpp
void World::drainRetryQueue() {
    std::vector<WorldJob> snapshot;
    { std::lock_guard lk(m_retryMtx); snapshot.swap(m_retryQueue); }
    for (auto& job : snapshot) {
        if (job.chunk && job.chunk->evicted.load()) { continue; } // skip dead
        if (!m_jobQueue.push(job)) {
            std::lock_guard lk(m_retryMtx);
            m_retryQueue.push_back(job);  // re-queue for next frame
        }
    }
}
```

Evicted chunks are discarded (no point retrying dead work).  The single-pass
design prevents starvation: if the queue is still full, jobs stay in `m_retryQueue`
and are re-attempted next frame — no infinite spin.

---

### Fix 4 · `World.cpp` — Upload budget scales at RD/4 instead of RD/8

**Root cause:** Old formula: `rdScale = max(1, effectiveRadius / 8)`.
At RD=8..15, `rdScale = 1` → upload budget = `maxUploadBudget × CLUSTER_STACK × 1`
= **24 cluster uploads/frame** (COOL state).

With 361 chunks × 4 clusters = 1444 total uploads needed at RD=8, this takes
`1444 / 24 ≈ 60 frames (~1 s)`.  Chunks complete generation and meshing quickly
but sit invisible in the `m_uploadQueue` waiting for the GPU upload pass to reach
them.  The `uploadedClusterCount < CLUSTER_STACK` guard keeps them hidden the
whole time.

**Fix:** Change `effectiveRadius / 8` → `effectiveRadius / 4`:

```cpp
int rdScale = max(1, m_effectiveRadius / 4);
```

Results (COOL):
- RD=4..7:  scale=1 →  24/frame (unchanged)
- RD=8..11: scale=2 → **48**/frame  (upload lag ÷2)
- RD=12..15: scale=3 → **72**/frame
- RD=16..19: scale=4 → **96**/frame

---

### Fix 5 · `World.cpp` + `World.h` — Comprehensive debug logging

New `m_frameCount` counter (incremented every `update()` call).
Every 60 frames (~1 s at 60 fps) a single `LOGI` line reports all streaming
telemetry in one shot:

```
[ HZCM Stream ] frame=240 RD=8 effectiveR=8 |
  queueSize=312/4096 queueFree=3656 overflowTotal=0 retryQ=0 |
  submitted=361 candidates=361 candidateIdx=361 skipped=0 |
  uploadBacklog=0 workers=4 visible=142
```

Fields: `frame`, `RD`, `effectiveR`, `queueSize/capacity`, `queueFree`,
`overflowTotal` (cumulative `push()` failures), `retryQ` (current retry queue
depth), `submitted` (m_submitted set size), `candidates`, `candidateIdx`,
`skipped` (safety-net duplicate skips), `uploadBacklog`, `workers`, `visible`.

Additionally:
- Overflow log on each submission-loop push failure (with queue state)
- `drainRetryQueue()` logs pushed/dropped/requeued counts per drain pass
- `enqueueChunkBuild()` logs each deferral (chunk coords + overflow total)

---

### Fix 6 · `World.h` + `World.cpp` — Stability: 4th worker thread, overflow counters

**Worker count:** Increased cap from 3 → **4** threads (`min(4, hw-1)`).  On
6-core mobile devices this gives 4 drain threads instead of 3, improving
secondary-job throughput by ~33% at high RD and preventing sustained queue
saturation under heavy load.

**Overflow counters:** Added `m_overflowCount` (`atomic<int>`) and
`m_retryQueueSize` (`atomic<int>`) to `World` for lock-free telemetry reads.
These are updated by both GL thread (submission loop) and worker threads
(enqueue helpers) using `fetch_add`/`store` with relaxed ordering — safe because
they're diagnostic only and no happens-before relationship is required.

**Deadlock prevention:** `drainRetryQueue()` uses a swap-then-release pattern:
the lock is held only for the `swap`, not for the push loop.  Workers can enqueue
into `m_retryQueue` concurrently with the GL thread draining it because each
direction holds `m_retryMtx` only for the minimum critical section.  This
eliminates any scenario where GL thread holds `m_retryMtx` while waiting for
`m_jobQueue.push()` and workers hold the job queue's internal spin waiting for
`m_retryMtx`.

**Infinite-retry guard:** Jobs that fail to push during `drainRetryQueue()` are
re-queued for next frame, not spin-retried.  Evicted chunks are discarded
unconditionally, so a permanently-saturated queue cannot accumulate stale entries
from dead chunks indefinitely.

---

## Files changed

| File | Fixes |
|------|-------|
| `core/hzcm/LockFreeJobQueue.h` | Fix 1 — capacity 1024→4096, `isFull()`, `approximateFree()` |
| `core/World.h` | Fix 3, 5, 6 — retry queue fields, debug counters |
| `core/World.cpp` | Fix 2, 3, 4, 5, 6 — budget formula, retry queue, upload scale, logging, workers |

No shader, save-format, API-surface, or platform changes.

---



## Bug Fixes — 4 targeted patches across 4 files

These fixes address two related root causes behind the "chunks skip / don't
generate during exploration" and "chunks only load near spawn" symptoms reported
in v11.

---

### Fix 1 · `World.h` — `m_submitted` was `std::set` (O(log N)) → GL-thread stall on every camera chunk-change

**Root cause:** The candidate filter in `World::update()` calls
`m_submitted.count()` once per candidate — up to `(2·RD+1)²` entries.  With
`std::set`, each lookup is `O(log N)`.  At RD=200 that is ~163 k lookups × 17
comparisons each ≈ **30–80 ms per camera chunk-move** on the GL thread.

This stall also pushed frame times into `ThermalManager`'s WARM/HOT state,
which cuts `effectiveRadius` to 75 % or 50 % and halves the chunk-submission
budget — compounding the loading problem.

**Fix:** Change `m_submitted` to `std::unordered_set<ChunkKey, ChunkKeyHash>`,
giving O(1) average lookup and reducing the filter pass to < 2 ms.

```cpp
// Before:
std::set<ChunkKey> m_submitted;

// After:
std::unordered_set<ChunkKey, ChunkKeyHash> m_submitted;
```

---

### Fix 2 · `World.cpp` `gatherAndDraw()` — Neighbour-generation guard blocked ALL frontier chunks from rendering → "chunks never appear during exploration"

**Root cause (the primary bug):** The v11 neighbour guard prevented drawing
chunk A if ANY cardinal neighbour existed in `m_chunks` but had not yet set
`generated = true` — i.e. was merely **queued**, not actively being processed.

The job ring holds 1 024 slots.  At any moderate-to-high render distance the
ring is nearly always full: ~1 000 chunks are simultaneously "in queue but
ungenerated".  Every chunk adjacent to any of those 1 000 pending chunks was
permanently invisible.  This produced the exact symptoms the user reported:

- Chunks appear near spawn (where all 4 neighbours generate quickly in the first
  few ring-drain cycles).
- Chunks stop appearing while exploring (frontier neighbours are always queued,
  so the guard never clears).

**Fix:** Tighten the guard to block only when a neighbour's `inFlight > 0` —
meaning a worker thread is actively generating it **right now**.  With 3
workers, at most 3 chunks are ever in-flight simultaneously.  The brief
floating-island faces that appear before `workerNeighbourFlush` corrects the
border mesh are vastly preferable to permanent invisibility.

```cpp
// Before (broken — blocks on any queued-but-ungenerated neighbour):
if (nb && !nb->generated.load(std::memory_order_acquire)) {
    waitingForNeighbour = true;
    break;
}

// After (correct — blocks only while a worker is mid-generation):
if (nb && !nb->generated.load(std::memory_order_acquire)
       &&  nb->inFlight.load(std::memory_order_acquire) > 0) {
    waitingForNeighbour = true;
    break;
}
```

---

### Fix 3 · `World.cpp` `update()` — `HierarchicalVisibility::rebuild` acquired ~163 k separate shared locks per camera chunk-change

**Root cause:** The visibility rebuild passed a lambda that called
`surfaceHeightAt()` for every cell in the `(2·RD+1)²` grid.
`surfaceHeightAt()` acquires its own `shared_lock<shared_mutex>` per call.
At RD=200 that is **163 201 separate lock acquisitions** per camera-chunk move,
adding another 30–100 ms of GL-thread work (on top of Fix 1's cost).

**Fix:** Snapshot all surface heights from `m_chunks` under **one** shared lock,
store in a local `unordered_map`, then pass a fast hash-map lookup as the
rebuild callback.

```cpp
std::unordered_map<ChunkKey, int, ChunkKeyHash> surfHeights;
{
    std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);   // ONE lock
    for (auto& kv : m_chunks) { /* fill surfHeights */ }
}   // lock released
m_visibility.rebuild(camCX, camCZ, camY, m_effectiveRadius,
    [&surfHeights](int cx, int cz) -> int {
        auto it = surfHeights.find({cx, cz});
        return it != surfHeights.end() ? it->second : 40;
    });
```

---

### Fix 4 · `PageAllocator.h` — `classFor` returned largest class for numFaces > 4096 → silent VBO buffer overflow

**Root cause:** When a dense surface cluster produced more than 4 096 mesh faces
(the `maxFaces` of class 3), `classFor` returned class 3 anyway.  The caller
then allocated a 4 096-face page and uploaded `numFaces` (> 4 096) bytes into
it — silently overwriting the next page in the VBO, causing visual corruption
and potential crashes in adjacent clusters.

**Fix A:** Return `-1` for requests beyond the largest class so `alloc()` safely
returns `MEGA_INVALID` instead of overflowing.

**Fix B:** Raise class 3's `maxFaces` and `pageSize` from 4 096 to **6 144** to
accommodate the densest realistic clusters without hitting `MEGA_INVALID`; raise
`numPages` from 100 to 120.

```cpp
// Before:
{4096, 4096, 100},   // Class 3: worst-case greedy mesh

// After:
{6144, 6144, 120},   // Class 3: very large decorated clusters
```

---

## Files changed

| File | Fixes |
|------|-------|
| `core/World.h` | Fix 1 — `m_submitted` type change |
| `core/World.cpp` | Fix 2 — neighbour guard, Fix 3 — visibility rebuild batching |
| `core/hzcm/PageAllocator.h` | Fix 4 — `classFor` overflow + class 3 size |

No API surface, shader, save-format, or platform changes.

---

# Previous: v10 → v11 fixes



## Bug Fixes — 6 targeted patches across 2 files

---

### Fix 1 · `StreamScheduler.h` — Priority sort violated ring ordering → far chunks loaded before nearby ones

**Root cause:** `sortByPriority` computed distance from the *lookahead* position
(`camX + smoothVel * 2.5 s`) and used `priority = 1/dist + 0.5 * align`.
With any non-zero velocity the lookahead sits far ahead of the camera, so a
chunk at Chebyshev ring 10 directly in front could have a *smaller*
lookahead-distance than a chunk at ring 2 behind the player, giving it higher
priority.  Result: far-forward chunks loaded before adjacent ones, leaving large
"nearby gaps" in terrain and causing the secondary island / seam bugs below to
persist for many more frames than necessary.

**Fix:** Two-part change to `sortByPriority`:

1. **Chebyshev ring as primary key** — `1e6 / (chebRing + 1)` dominates for
   every ring 0..200, guaranteeing ring N always beats ring N+1 regardless of
   direction bias.  (Gap between consecutive rings > `FORWARD_BIAS = 0.5` for
   all N ≤ 1413, safely covering `RD_MAX = 200`.)

2. **Direction alignment as sub-ring tiebreaker** — computed from the actual
   camera forward vector to the chunk centre; *not* from the lookahead distance.
   Lookahead velocity smoothing is retained for jitter reduction but no longer
   distorts the ring ordering.

```cpp
// Before (broken — lookahead distance as primary):
float dx = cx - lookX, dz = cz - lookZ;
float dist = sqrtf(dx*dx + dz*dz) + 0.001f;
cp.priority = (1.f / dist) + FORWARD_BIAS * align;

// After (fixed — Chebyshev ring primary, direction secondary):
int cheb = std::max(std::abs(cp.cx - camCX), std::abs(cp.cz - camCZ));
cp.priority = 1000000.f / (float)(cheb + 1) + FORWARD_BIAS * align;
```

---

### Fix 2 · `World.cpp` `update()` — Candidate list wasted per-frame budget on already-submitted entries → slow peripheral loading

**Root cause:** `m_pendingCandidates` was built from the full O(RD²) square of
chunks including every already-loaded one.  The submission loop advanced
`m_candidateIdx` by 1 whether it submitted or skipped.  At RD=7 (~289 chunks),
each camera-chunk move burned ~289 `continue` iterations before touching a new
chunk; at RD=20 (~1764 chunks) this ballooned to ~1560 skips.  With `maxNew`
capped at 8–32, new peripheral chunks waited `(loadedCount / maxNew)` extra
frames to be submitted — compounding the priority bug above.

**Fix:** After `buildCandidates` and before `sortByPriority`, remove every entry
already in `m_submitted` via `std::remove_if`.  The remaining list contains only
unsubmitted work; every slot the submission loop visits is a genuine new chunk.

```cpp
auto newEnd = std::remove_if(
    m_pendingCandidates.begin(), m_pendingCandidates.end(),
    [this](const ChunkPriority& cp) {
        return m_submitted.count({cp.cx, cp.cz}) != 0;
    });
m_pendingCandidates.erase(newEnd, m_pendingCandidates.end());
// sort AFTER filter so priority order is over new chunks only
m_scheduler.sortByPriority(m_pendingCandidates);
```

Correctness: `m_submitted ⊆ m_chunks` at all times (eviction removes from
both), so this filter never discards a chunk that needs re-generation.

---

### Fix 3 · `World.cpp` `workerNeighbourFlush()` — DIRTY-state neighbours silently skipped → permanent border seams

**Root cause:** `workerNeighbourFlush` only enqueued `CLUSTER_REBUILD` for
neighbours in `READY` or `MESHED` state.  If a neighbour had called
`generate()` (setting `generated = true`) but its own `CHUNK_BUILD` job had not
yet reached `buildClusterMesh()`, its clusters were still `DIRTY`.  The flush
skipped them silently.  The neighbour's later stale-check also missed the race
(it compared pointers captured before its own `generate()` completed, not after).
Result: a narrow but reproducible window where a border seam was never corrected.

**Fix:** Collect two work-sets inside the shared lock:

- `remesh` — existing `READY`/`MESHED` clusters (border correction, unchanged).
- `initMesh` — generated neighbours with ALL clusters in `DIRTY`/`EMPTY` state,
  meaning their first mesh hasn't happened yet.  Enqueue a `CHUNK_BUILD` so they
  mesh with correct data from the now-available neighbour.

```cpp
if (!anyMeshed && !nb->evicted.load(std::memory_order_acquire))
    initMesh.push_back(nb);
// ...
for (Chunk* nb : initMesh)
    enqueueChunkBuild(nb);  // safe: see Fix 4
```

---

### Fix 4 · `World.cpp` `workerChunkBuild()` — Re-entering generate() on an already-generated chunk

**Root cause (new, introduced by Fix 3):** `workerNeighbourFlush` can now
enqueue `CHUNK_BUILD` for a chunk that is already generated but not yet meshed.
The old `workerChunkBuild` called `chunk->generate()` unconditionally, which
would overwrite existing block data and reset cluster states.

**Fix:** Guard `generate()` with a `!chunk->generated.load()` check.  If the
terrain is already present, skip straight to `buildClusterMesh()` using the
current (now-available) neighbours.

```cpp
if (!chunk->generated.load(std::memory_order_acquire)) {
    chunk->generate(m_noise);
    if (chunk->evicted.load(std::memory_order_acquire)) { ... return; }
}
// fall through to buildClusterMesh() in all cases
```

---

### Fix 5 · `World.cpp` `gatherAndDraw()` — Floating-island rendering before border mesh is corrected

**Root cause:** A chunk became visible (uploadedClusterCount == CLUSTER_STACK)
immediately after its first GPU upload, even when its initial mesh was built with
BLOCK_AIR on one or more sides (neighbours didn't exist yet).  The incorrect mesh
— visible faces on every border plane — produced the "floating island" look.
`workerNeighbourFlush` eventually corrects the mesh, but the old priority sort
(Fix 1) delayed neighbour generation, stretching the artifact window to tens of
seconds at larger render distances.

**Fix:** After the existing `uploadedClusterCount` guard, add a
*neighbour-generation guard*: if any cardinal neighbour exists in `m_chunks` but
has not yet set `generated = true`, skip drawing this chunk.  The shared lock is
already held, making `getChunk` safe with zero extra locking overhead.

```cpp
static const int CDIRS[4][2] = {{-1,0},{1,0},{0,-1},{0,1}};
bool waitingForNeighbour = false;
for (int d = 0; d < 4; ++d) {
    const Chunk* nb = getChunk(ch->cx + CDIRS[d][0], ch->cz + CDIRS[d][1]);
    if (nb && !nb->generated.load(std::memory_order_acquire)) {
        waitingForNeighbour = true; break;
    }
}
if (waitingForNeighbour) continue;
```

Neighbours outside load range (null) are treated as air and never block
rendering; edge-of-world chunks are therefore never permanently hidden.

---

### Fix 6 · `World.cpp` `update()` — Stale `m_submitted` entries after render-distance change → missing chunks

**Root cause:** The queue-full rollback path in the submission loop removed a
chunk from `m_chunks` but could not remove it from `m_submitted` (the entry is
only inserted *after* a successful push).  In pathological multi-frame sequences
— queue full, RD change, resubmission attempted — `m_submitted` could contain a
key that no longer had a corresponding entry in `m_chunks`.  On the next
candidate rebuild the key was filtered as "already submitted", silently
preventing re-submission of that chunk indefinitely.

**Fix:** Inside the write-lock scope of the unload pass, when `rdChanged`, scan
`m_submitted` and erase any key absent from `m_chunks`.  This runs O(loaded
chunks) once per RD change event — a rare operation — and makes the two
structures provably consistent at every render-distance boundary.

```cpp
if (rdChanged) {
    for (auto sit = m_submitted.begin(); sit != m_submitted.end(); ) {
        if (m_chunks.find({sit->cx, sit->cz}) == m_chunks.end())
            sit = m_submitted.erase(sit);
        else
            ++sit;
    }
}
```

---

## Files changed

| File | Changes |
|------|---------|
| `core/hzcm/StreamScheduler.h` | Fix 1 — `sortByPriority` priority formula |
| `core/World.cpp` | Fixes 2–6 — candidate filter, neighbour flush, generate guard, draw guard, RD sync |

No API surface, shader, data-layout, or platform changes.
