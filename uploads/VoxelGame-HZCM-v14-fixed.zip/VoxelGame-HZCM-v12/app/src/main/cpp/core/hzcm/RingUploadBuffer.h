#pragma once
// ============================================================================
// HZCM v4 — RingUploadBuffer.h
// Triple-buffered CPU→GPU upload ring for Android GLES 3.0.
//
// Problem:
//   glBufferSubData stalls when the GPU is reading the target range,
//   causing CPU-side upload spikes that hitch frames and create thermal bursts.
//
// Solution:
//   Three-slot ring.  Each slot is a fixed CPU staging array.
//   Every frame: fill staging → glMapBufferRange(UNSYNCHRONIZED) → unmap.
//   A GLsync fence guards each slot; we wait on the slot 3 frames old before
//   reusing it, ensuring the GPU has finished consuming that upload.
//
//   This eliminates all CPU/GPU synchronisation on the upload path.
//   glMapBufferRange with GL_MAP_UNSYNCHRONIZED_BIT tells the driver NOT to
//   wait for the GPU — we take responsibility for the fence ourselves.
//
// Usage per frame:
//   1. ring.beginFrame(vbo);              // may wait on old fence, resets staging
//   2. ring.stage(dstOffset, data, n);    // memcpy into CPU staging
//      ... repeat for each dirty cluster
//   3. ring.flush();                      // one glMapBufferRange + memcpy + fence
//
// The flush step uploads all staged data in one driver call, amortising
// the per-call setup cost vs. N separate glBufferSubData calls.
//
// GLES 3.0 compatibility: uses GL_MAP_WRITE_BIT | GL_MAP_INVALIDATE_RANGE_BIT
// | GL_MAP_UNSYNCHRONIZED_BIT (all required by GLES 3.0 spec §2.9.3).
// ============================================================================
#ifndef GLES3_GL3_H_STUB
#include <GLES3/gl3.h>
#endif
#include <cstdint>
#include <cstring>
#include <vector>
#include <android/log.h>
#include "ClusterTypes.h"  // PackedFace, MEGA_INVALID

// ── Configuration ─────────────────────────────────────────────────────────────
// How many PackedFaces can be staged per frame before we flush mid-frame.
// At 8 bytes/face and a typical budget of 6 uploads × ~500 faces = 3000 faces
// → 24 KB.  We budget generously at 32 K faces = 256 KB to handle rare bursts.
static constexpr uint32_t RING_STAGING_FACES = 32768u;
static constexpr int      RING_SLOTS         = 3;   // triple-buffer

class RingUploadBuffer {
public:
    RingUploadBuffer() {
        // Pre-allocate CPU staging arenas
        for (int s = 0; s < RING_SLOTS; ++s) {
            m_staging[s].resize(RING_STAGING_FACES);
            m_fences[s] = nullptr;
        }
    }

    ~RingUploadBuffer() {
        for (int s = 0; s < RING_SLOTS; ++s)
            if (m_fences[s]) glDeleteSync(m_fences[s]);
    }

    // ── Begin frame: prepare the current ring slot ────────────────────────────
    // Call on GL thread at the start of updateGPU().
    void beginFrame(GLuint vbo) {
        m_vbo = vbo;
        int slot = m_frameIdx % RING_SLOTS;

        // Wait on the fence we placed 3 frames ago (if any) before reusing.
        if (m_fences[slot]) {
            GLenum result = glClientWaitSync(m_fences[slot],
                GL_SYNC_FLUSH_COMMANDS_BIT,
                5'000'000 /* 5 ms timeout in nanoseconds */);

            if (result == GL_TIMEOUT_EXPIRED) {
                // Driver didn't finish in 5 ms — force wait
                glClientWaitSync(m_fences[slot], 0, GL_TIMEOUT_IGNORED);
            }
            glDeleteSync(m_fences[slot]);
            m_fences[slot] = nullptr;
        }

        m_currentSlot  = slot;
        m_stagingHead  = 0;
        m_pendingCount = 0;
    }

    // ── Stage one cluster's faces for upload ──────────────────────────────────
    // `dstOffset` = face offset in MegaBuffer (from PageAllocator::alloc).
    // Returns false if staging is full (caller should flush mid-frame).
    bool stage(uint32_t dstOffset, const PackedFace* data, uint32_t numFaces) {
        if (numFaces == 0) return true;
        if (m_stagingHead + numFaces > RING_STAGING_FACES) return false;
        if (m_pendingCount >= MAX_PENDING) return false;

        // Copy into CPU staging arena for this slot
        memcpy(&m_staging[m_currentSlot][m_stagingHead],
               data, numFaces * sizeof(PackedFace));

        m_pending[m_pendingCount++] = { dstOffset, m_stagingHead, numFaces };
        m_stagingHead += numFaces;
        return true;
    }

    // ── Flush: one driver round-trip uploads everything staged this frame ──────
    // Uses glMapBufferRange(UNSYNCHRONIZED) to avoid GPU stalls.
    // Insert a GLsync fence so we know when the GPU is done with this data.
    void flush() {
        if (m_pendingCount == 0) { ++m_frameIdx; return; }

        glBindBuffer(GL_ARRAY_BUFFER, m_vbo);

        // Sort pending by destination offset for sequential GPU writes
        // (small insertion sort — typically < 10 uploads per frame)
        for (uint32_t i = 1; i < m_pendingCount; ++i) {
            Pending tmp = m_pending[i];
            uint32_t j = i;
            while (j > 0 && m_pending[j-1].dstOffset > tmp.dstOffset) {
                m_pending[j] = m_pending[j-1];
                --j;
            }
            m_pending[j] = tmp;
        }

        // Upload each pending region via glMapBufferRange
        for (uint32_t i = 0; i < m_pendingCount; ++i) {
            const Pending& p = m_pending[i];
            GLintptr  byteOffset  = (GLintptr)(p.dstOffset * sizeof(PackedFace));
            GLsizeiptr byteLen    = (GLsizeiptr)(p.count   * sizeof(PackedFace));

            void* ptr = glMapBufferRange(GL_ARRAY_BUFFER, byteOffset, byteLen,
                GL_MAP_WRITE_BIT |
                GL_MAP_INVALIDATE_RANGE_BIT |
                GL_MAP_UNSYNCHRONIZED_BIT);

            if (ptr) {
                memcpy(ptr, &m_staging[m_currentSlot][p.srcHead],
                       byteLen);
                glUnmapBuffer(GL_ARRAY_BUFFER);
            } else {
                // Fallback: glBufferSubData (driver may stall, but at least correct)
                glBufferSubData(GL_ARRAY_BUFFER, byteOffset, byteLen,
                    &m_staging[m_currentSlot][p.srcHead]);
                __android_log_print(ANDROID_LOG_WARN, "RingUpload",
                    "glMapBufferRange failed, fell back to glBufferSubData");
            }
        }

        // Insert fence — guards this slot until frame+3
        m_fences[m_currentSlot] = glFenceSync(GL_SYNC_GPU_COMMANDS_COMPLETE, 0);

        ++m_frameIdx;
    }

    // Diagnostics
    uint32_t stagedFacesThisFrame() const { return m_stagingHead; }
    uint32_t pendingUploadsThisFrame() const { return m_pendingCount; }

private:
    GLuint m_vbo     = 0;
    int    m_frameIdx = 0;
    int    m_currentSlot = 0;

    // CPU staging memory — RING_SLOTS separate arenas
    std::vector<PackedFace> m_staging[RING_SLOTS];

    // GL sync objects — one per ring slot
    GLsync m_fences[RING_SLOTS];

    // Pending upload descriptors for current frame
    struct Pending {
        uint32_t dstOffset;  // face offset in MegaBuffer
        uint32_t srcHead;    // face offset within m_staging[slot]
        uint32_t count;
    };
    static constexpr uint32_t MAX_PENDING = 256;
    Pending  m_pending[MAX_PENDING];
    uint32_t m_pendingCount = 0;
    uint32_t m_stagingHead  = 0;
};
