#pragma once
// ============================================================================
// HZCM v4 — StreamScheduler.h
// Predictive chunk streaming — now driven by RenderDistanceSystem.
//
// Changes from v3:
//   • Receives render distance from RenderDistanceSystem rather than a
//     compile-time constant → supports runtime hot-reload 2..200.
//   • buildCandidates() accepts an explicit radius parameter.
//   • Added per-chunk distance ring for annular load scheduling.
//   • Priority formula extended with altitude bias: chunks at camera altitude
//     get higher priority (reduces popping of surface clusters).
// ============================================================================
#include <cmath>
#include <vector>
#include <algorithm>

struct ChunkPriority {
    int   cx, cz;
    float priority;
};

class StreamScheduler {
public:
    // How far ahead (seconds) we predict camera movement
    static constexpr float LOOKAHEAD_S   = 2.5f;
    // FORWARD_BIAS intentionally removed from generation priority.
    //
    // Root bug (v12 → v14 fix):
    //   FORWARD_BIAS = 0.5 caused chunks in the camera direction to always be
    //   submitted before side / behind chunks within the same Chebyshev ring.
    //   Combined with m_candidateIdx resetting to 0 on every camMoved rebuild
    //   (which happens every frame while the player explores), the side/behind
    //   chunks were perpetually re-sorted to the bottom and NEVER reached the
    //   submission budget before the next rebuild.  Symptoms:
    //     • "only forward-facing chunks generate while exploring"
    //     • "RD 7→9 skips the outer rings in non-forward directions"
    //     • "holes until the player looks in that direction"
    //
    // Fix: generation uses PURE Chebyshev-ring distance — fair in all
    // directions.  Ring N still always beats ring N+1 (1e6 / (N+1) > 1e6 / (N+2)),
    // so nearby chunks still load before far ones.  The forward-looking
    // preference that helped UX can be re-introduced ONLY for the GPU upload
    // sort (updateGPU), which already uses chebDist nearest-first.
    static constexpr float ALTITUDE_BIAS = 0.2f;  // retained for documentation

    // ── Camera state update (call every frame) ────────────────────────────────
    void update(float camX, float camZ, float camY,
                float velX, float velZ,
                float fwdX, float fwdZ)
    {
        m_camX = camX; m_camZ = camZ; m_camY = camY;
        m_velX = velX; m_velZ = velZ;
        m_fwdX = fwdX; m_fwdZ = fwdZ;

        // Smooth velocity with EMA to reduce jitter
        m_smoothVX = m_smoothVX * 0.85f + velX * 0.15f;
        m_smoothVZ = m_smoothVZ * 0.85f + velZ * 0.15f;
    }

    // ── Sort candidates by priority (highest first) ───────────────────────────
    //
    // v11 fix: replaced lookahead-Euclidean formula with Chebyshev ring formula
    //   priority = 1e6 / (chebRing + 1)
    // to guarantee strict nearest-ring-first ordering across all directions.
    //
    // v14 fix: removed FORWARD_BIAS directional tiebreaker.
    //   The old formula added `FORWARD_BIAS * align` (0..0.5) per chunk.
    //   Ring ordering was preserved (1e6 gap >> 0.5), but WITHIN each ring
    //   forward-facing chunks were always submitted before side/behind chunks.
    //   Because m_candidateIdx resets to 0 on every camMoved rebuild (every
    //   frame while exploring), the submission budget (maxNew ≈ 16-32/frame)
    //   was spent entirely on forward-facing ring slices — side and behind
    //   chunks were perpetually re-sorted to the bottom and never submitted.
    //
    //   Fix: pure Chebyshev-ring distance with NO directional tiebreaker.
    //   Every chunk at ring N loads before ring N+1, regardless of direction.
    //   This makes generation deterministic, complete, and fair in all directions.
    //   Forward-look optimisation can be applied to the GPU upload sort instead
    //   (updateGPU already sorts nearest-first; forward-facing bias there is
    //   purely a visual nicety that cannot starve generation).
    void sortByPriority(std::vector<ChunkPriority>& candidates) const {
        // Actual camera chunk coords for Chebyshev ring distance.
        // 16 == CHUNK_W == CHUNK_D (from ClusterTypes.h).
        int camCX = (int)floorf(m_camX / 16.f);
        int camCZ = (int)floorf(m_camZ / 16.f);

        for (auto& cp : candidates) {
            // Pure Chebyshev-ring distance — no directional bias.
            // Ring 0 (current chunk) priority = 1e6.
            // Ring 1 = 500000.  Ring 9 = 100000.  Ring 200 = ~4975.
            // Guarantees: near always before far, all directions treated equally.
            int cheb = std::max(std::abs(cp.cx - camCX), std::abs(cp.cz - camCZ));
            cp.priority = 1000000.f / (float)(cheb + 1);
        }

        std::sort(candidates.begin(), candidates.end(),
            [](const ChunkPriority& a, const ChunkPriority& b) {
                return a.priority > b.priority;
            });
    }

    // ── Build candidate list for a given radius ───────────────────────────────
    // renderRadius is the FULL radius from RenderDistanceSystem (2..200).
    // innerR lets callers build annular rings (e.g., only newly-in-range chunks).
    static void buildCandidates(int camCX, int camCZ,
                                int innerR, int outerR,
                                std::vector<ChunkPriority>& out)
    {
        out.clear();
        // Reserve to avoid re-allocation during fill
        int diam = outerR * 2 + 1;
        out.reserve((size_t)(diam * diam));

        for (int dz = -outerR; dz <= outerR; ++dz) {
            for (int dx = -outerR; dx <= outerR; ++dx) {
                int dist = std::max(std::abs(dx), std::abs(dz));
                if (dist < innerR || dist > outerR) continue;
                out.push_back({ camCX + dx, camCZ + dz, 0.f });
            }
        }
    }

private:
    float m_camX = 0.f, m_camZ = 0.f, m_camY = 64.f;
    float m_velX = 0.f, m_velZ = 0.f;
    float m_fwdX = 0.f, m_fwdZ = 1.f;
    float m_smoothVX = 0.f, m_smoothVZ = 0.f;
};
