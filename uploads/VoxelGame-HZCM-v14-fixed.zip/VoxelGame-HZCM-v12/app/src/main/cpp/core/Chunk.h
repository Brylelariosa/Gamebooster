#pragma once
// ============================================================================
// HZCM v4 — Chunk.h  (16×64×16 block column, 4 × 16³ clusters)
// ============================================================================
#include <cstdint>
#include <vector>
#include <atomic>
#include <mutex>
#include <cstring>
#include "Block.h"
#include "Noise.h"
#include "hzcm/ClusterTypes.h"
#include "hzcm/ClusterMesher.h"

class Chunk {
public:
    int cx = 0, cz = 0;

    // Block storage: XYZ order, index = x + 16*(y + 64*z)
    uint8_t blocks[CHUNK_W * CHUNK_H * CHUNK_D];

    // Per-cluster CPU face buffers
    std::vector<PackedFace> clusterFaces[CLUSTER_STACK];
    std::mutex              clusterMutex[CLUSTER_STACK];

    // Per-cluster lifecycle
    std::atomic<ClusterState> clusterState[CLUSTER_STACK];

    // GPU residency — written/read on GL thread only
    uint32_t clusterGPUOffset[CLUSTER_STACK];
    uint32_t clusterFaceCount[CLUSTER_STACK];

    // Dirty generation counter: bumped each time a rebuild is enqueued.
    uint32_t clusterDirtyGen[CLUSTER_STACK];

    // Eviction safety:
    //   When World evicts this chunk it sets `evicted = true` BEFORE removing
    //   the unique_ptr from the map.  Workers check this flag at entry and
    //   skip all work if set — guaranteeing the chunk is not written after
    //   its storage is handed to the graveyard for deferred deletion.
    std::atomic<bool> evicted{false};

    // Count of worker jobs currently running against this chunk.
    // Graveyard deletion waits until this reaches 0.
    std::atomic<int> inFlight{0};

    // True once generate() completes
    std::atomic<bool> generated{false};

    // Counts how many distinct clusters have been uploaded to GPU at least once.
    // Written ONLY on the GL thread inside updateGPU, so no worker-thread race.
    // When this reaches CLUSTER_STACK the chunk may be drawn.  It never resets,
    // so mid-rebuild clusters continue showing their old mesh while the new one
    // is being staged — the old "allClustersUploaded" boolean had a race where
    // a workerClusterRebuild could set state back to MESHED between the GL
    // thread setting the last cluster READY and reading all states, keeping the
    // flag false and the chunk permanently hidden.
    int      uploadedClusterCount{0};   // GL-thread only, no atomic needed
    uint32_t clusterFirstUploadMask{0}; // bit i = cluster i has been uploaded once

    // ─────────────────────────────────────────────────────────────────────────
    Chunk(int cx, int cz);
    ~Chunk() = default;

    inline uint8_t getBlock(int x, int y, int z) const {
        if ((unsigned)x >= (unsigned)CHUNK_W ||
            (unsigned)y >= (unsigned)CHUNK_H ||
            (unsigned)z >= (unsigned)CHUNK_D) return BLOCK_AIR;
        return blocks[x + CHUNK_W * (y + CHUNK_H * z)];
    }
    inline void setBlock(int x, int y, int z, uint8_t t) {
        if ((unsigned)x >= (unsigned)CHUNK_W ||
            (unsigned)y >= (unsigned)CHUNK_H ||
            (unsigned)z >= (unsigned)CHUNK_D) return;
        blocks[x + CHUNK_W * (y + CHUNK_H * z)] = t;
    }

    void generate(const Noise& noise);
    void extractClusterVoxels(int ci, uint8_t out[CL_VOLUME]) const;
    void buildClusterMesh(int ci,
                          const Chunk* nx, const Chunk* px,
                          const Chunk* nz, const Chunk* pz);

    void getAABB(float& mnX, float& mnY, float& mnZ,
                 float& mxX, float& mxY, float& mxZ) const;

    inline int clusterWorldX(int)    const { return cx * CHUNK_W; }
    inline int clusterWorldY(int ci) const { return ci * CL_SIZE;  }
    inline int clusterWorldZ(int)    const { return cz * CHUNK_D;  }
};
