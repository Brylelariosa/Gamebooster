#include "Noise.h"
#include <cmath>
#include <algorithm>

Noise::Noise(int seed) {
    // Fill permutation table
    for (int i = 0; i < 256; i++) perm[i] = i;

    // Shuffle using LCG seeded by seed
    unsigned int s = (unsigned int)seed;
    for (int i = 255; i > 0; i--) {
        s = s * 1664525u + 1013904223u;
        int j = (int)(s & 0xFFu) % (i + 1);
        int tmp = perm[i]; perm[i] = perm[j]; perm[j] = tmp;
    }

    // Duplicate to avoid modular indexing
    for (int i = 0; i < 256; i++) perm[256 + i] = perm[i];
}

float Noise::grad(int hash, float x, float y) const {
    int h = hash & 7;
    float u = h < 4 ? x : y;
    float v = h < 4 ? y : x;
    return ((h & 1) ? -u : u) + ((h & 2) ? -v : v);
}

float Noise::noise2D(float x, float y) const {
    int xi = (int)floorf(x) & 255;
    int yi = (int)floorf(y) & 255;
    float xf = x - floorf(x);
    float yf = y - floorf(y);

    float u = fade(xf);
    float v = fade(yf);

    int aa = perm[perm[xi]   + yi];
    int ab = perm[perm[xi]   + yi + 1];
    int ba = perm[perm[xi+1] + yi];
    int bb = perm[perm[xi+1] + yi + 1];

    float res = lerp(
        lerp(grad(aa, xf,   yf),   grad(ba, xf-1.f, yf),   u),
        lerp(grad(ab, xf,   yf-1.f), grad(bb, xf-1.f, yf-1.f), u),
        v
    );
    return res; // approximately in [-1, 1]
}

float Noise::fbm(float x, float y, int octaves, float lacunarity, float gain) const {
    float value = 0.0f;
    float amplitude = 0.5f;
    float frequency = 1.0f;
    float maxValue  = 0.0f;

    for (int i = 0; i < octaves; i++) {
        value    += noise2D(x * frequency, y * frequency) * amplitude;
        maxValue += amplitude;
        amplitude *= gain;
        frequency *= lacunarity;
    }

    return value / maxValue; // normalize to [-1, 1]
}
