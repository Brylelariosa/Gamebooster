#pragma once
// ============================================================================
// HZCM v4 — ThermalManager.h
// Adaptive rebuild/upload budgeting with streaming radius scaling.
//
// Changes from v3:
//   • Added streaming radius multiplier: under sustained thermal load the
//     effective render distance is reduced to cut streaming work.
//   • radiusScale() exposed so RenderDistanceSystem can compute the
//     thermally-limited effective radius per frame.
//   • Budget tables tuned for 60/45/30 fps target tiers.
//   • Added CRITICAL state for devices running hotter than HOT.
// ============================================================================
#include <cstdint>
#include <algorithm>
#include <cmath>

class ThermalManager {
public:
    // ── Thermal states ────────────────────────────────────────────────────────
    enum State : uint8_t { COOL = 0, WARM = 1, HOT = 2, CRITICAL = 3 };

    // ── Thresholds (frame time ms) ────────────────────────────────────────────
    static constexpr float TARGET_MS   = 16.67f;  // 60 fps
    static constexpr float WARM_MS     = 22.2f;   // 45 fps
    static constexpr float HOT_MS      = 33.3f;   // 30 fps
    static constexpr float CRITICAL_MS = 50.0f;   // 20 fps
    static constexpr float COOL_MS     = 18.0f;   // 55 fps (hysteresis)

    // ── Per-state rebuild/upload budgets ──────────────────────────────────────
    //   Rebuild = max cluster remeshes per frame (CPU work)
    //   Upload  = max ring-buffer stage() calls per frame
    struct Budget { int rebuild; int upload; };
    static constexpr Budget BUDGETS[4] = {
        { 8, 6 },  // COOL:     full rate
        { 4, 4 },  // WARM:     halved
        { 2, 2 },  // HOT:      quarter
        { 1, 1 },  // CRITICAL: survival mode
    };

    // ── Streaming radius scale [0..1] ─────────────────────────────────────────
    // Applied to render distance: effective = max(2, (int)(requested × scale)).
    static constexpr float RADIUS_SCALES[4] = {
        1.00f,   // COOL
        0.75f,   // WARM
        0.50f,   // HOT
        0.30f,   // CRITICAL
    };

    // ── EMA configuration ─────────────────────────────────────────────────────
    static constexpr float EMA_ALPHA = 0.125f;  // ~8-sample window

    // ─────────────────────────────────────────────────────────────────────────
    void update(float dt_seconds) {
        float ms = dt_seconds * 1000.f;
        m_ema = (m_ema < 0.f) ? ms : m_ema + EMA_ALPHA * (ms - m_ema);

        // State machine with hysteresis
        switch (m_state) {
            case COOL:
                if (m_ema > WARM_MS)     m_state = WARM;
                break;
            case WARM:
                if (m_ema > HOT_MS)      m_state = HOT;
                else if (m_ema < COOL_MS) m_state = COOL;
                break;
            case HOT:
                if (m_ema > CRITICAL_MS) m_state = CRITICAL;
                else if (m_ema < COOL_MS) m_state = WARM;
                break;
            case CRITICAL:
                if (m_ema < COOL_MS)     m_state = HOT;
                break;
        }
    }

    int   maxRebuildBudget() const { return BUDGETS[m_state].rebuild; }
    int   maxUploadBudget()  const { return BUDGETS[m_state].upload;  }

    // Scale factor to apply to requested render distance.
    // Caller: effectiveRadius = max(2, (int)(requestedRadius × radiusScale()))
    float radiusScale() const { return RADIUS_SCALES[m_state]; }

    // [0.0 = cool .. 1.0 = critical] — for debug HUD
    float thermalPressure() const {
        float t = (m_ema - TARGET_MS) / (CRITICAL_MS - TARGET_MS);
        return std::max(0.f, std::min(1.f, t));
    }

    float  frameEmaMs()    const { return m_ema; }
    State  thermalState()  const { return m_state; }

    const char* stateString() const {
        switch (m_state) {
            case COOL:     return "COOL";
            case WARM:     return "WARM";
            case HOT:      return "HOT";
            case CRITICAL: return "CRITICAL";
        }
        return "?";
    }

private:
    float m_ema   = -1.f;
    State m_state = COOL;
};
