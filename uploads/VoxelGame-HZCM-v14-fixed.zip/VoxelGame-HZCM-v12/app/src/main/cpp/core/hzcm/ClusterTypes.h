#pragma once
// ============================================================================
// HZCM v4 — ClusterTypes.h
// Hierarchical Zoned Cluster Meshing — core data types.
//
// Changes from v3:
//   • DirtySlice bitmask: tracks which 16×16 Y-slices within a cluster
//     changed, enabling the mesher to skip unmodified slices.
//   • ClusterGPUSlot extended with the allocated page size so free() can
//     be called without a separate lookup.
//   • generationStamp to detect stale upload queue entries.
// ============================================================================
#include <cstdint>
#include <cstddef>
#include <atomic>

// ── Dimensions ────────────────────────────────────────────────────────────────
static constexpr int CHUNK_W       = 16;
static constexpr int CHUNK_H       = 64;
static constexpr int CHUNK_D       = 16;
static constexpr int CL_SIZE       = 16;
static constexpr int CL_VOLUME     = CL_SIZE * CL_SIZE * CL_SIZE;
static constexpr int CLUSTER_STACK = CHUNK_H / CL_SIZE;  // 4

// ── MegaBuffer sentinel ───────────────────────────────────────────────────────
static constexpr uint32_t MEGA_INVALID = 0xFFFF'FFFFu;

// ── PackedFace — 8 bytes per greedy-merged visible face ──────────────────────
//
// Word 0 [geom]:
//   bits  2:0   faceDir (0=+X 1=-X 2=+Y 3=-Y 4=+Z 5=-Z)
//   bits  6:3   ox  cluster-local X origin (0-15)
//   bits 10:7   oy  cluster-local Y origin (0-15)
//   bits 14:11  oz  cluster-local Z origin (0-15)
//   bits 18:15  span0-1 (0→1 .. 15→16)
//   bits 22:19  span1-1 (0→1 .. 15→16)
//
// Word 1 [mat]:
//   bits  7:0   block type
//   bits 15:8   AO corners (4 × 2-bit: corner0=bits9:8, etc.)
struct PackedFace {
    uint32_t geom;
    uint32_t mat;
};
static_assert(sizeof(PackedFace) == 8, "PackedFace size");

inline PackedFace makeFace(int faceDir,
                            int ox, int oy, int oz,
                            int span0, int span1,
                            int blockType,
                            uint8_t ao0=3, uint8_t ao1=3,
                            uint8_t ao2=3, uint8_t ao3=3)
{
    PackedFace f;
    f.geom = static_cast<uint32_t>(
        (faceDir         &  7u)        |
        ((ox             & 15u) <<  3u) |
        ((oy             & 15u) <<  7u) |
        ((oz             & 15u) << 11u) |
        (((span0 - 1)    & 15u) << 15u) |
        (((span1 - 1)    & 15u) << 19u));

    f.mat = static_cast<uint32_t>(
        (blockType       & 255u)        |
        ((ao0            &   3u) <<  8u) |
        ((ao1            &   3u) << 10u) |
        ((ao2            &   3u) << 12u) |
        ((ao3            &   3u) << 14u));
    return f;
}

// ── GPU residency record ──────────────────────────────────────────────────────
struct ClusterGPUSlot {
    uint32_t megaOffset = MEGA_INVALID;  // face offset in mega VBO
    uint32_t faceCount  = 0;
    uint32_t allocSize  = 0;            // actual page size from PageAllocator
    bool     resident   = false;
};

// ── Lifecycle states ──────────────────────────────────────────────────────────
enum class ClusterState : uint8_t {
    EMPTY  = 0,  // no block data
    DIRTY  = 1,  // block data ready, needs meshing
    MESHED = 2,  // CPU face buffer ready, awaiting GPU upload
    READY  = 3,  // GPU-resident, renderable
};

// ── Dirty slice bitmask ───────────────────────────────────────────────────────
// A 16³ cluster has 16 Y-slices.  Each bit marks one slice as changed.
// Used by the future partial mesher; currently set to 0xFFFF (all dirty)
// when a full rebuild is needed.
using DirtySliceMask = uint16_t;
static constexpr DirtySliceMask DIRTY_ALL   = 0xFFFFu;
static constexpr DirtySliceMask DIRTY_NONE  = 0x0000u;

inline DirtySliceMask dirtySliceForY(int localY) {
    return static_cast<DirtySliceMask>(1u << (localY & 15));
}

// ── Cluster descriptor (one per 16³ cluster, 4 per Chunk) ────────────────────
struct alignas(64) ClusterDesc {
    std::atomic<ClusterState> state{ClusterState::EMPTY};
    ClusterGPUSlot            gpu;
    DirtySliceMask            dirtySlices  = DIRTY_ALL;
    uint32_t                  dirtyGen     = 0;   // bump on each rebuild request
    uint32_t                  uploadGen    = 0;   // gen at time of last upload enqueue
    int                       worldX = 0;
    int                       worldY = 0;
    int                       worldZ = 0;

    // Pad to 64 bytes to prevent false sharing between adjacent clusters
    // Conservative 20-byte pad to reach 64 bytes.
    // Sized from: atomic(4) + GPUSlot(16) + DirtySlice+pad(4) + 3×uint32(12) + 3×int(12) = 48
    // 64 - 48 = 16, add 4 extra for alignment slack → 20.
    uint8_t _pad[20];
};
// Guard: if compiler packs members tighter or larger than expected,
// the assert fires at compile time — adjust _pad size accordingly.
static_assert(sizeof(ClusterDesc) == 64, "ClusterDesc must be exactly one cache line (64 bytes)");
