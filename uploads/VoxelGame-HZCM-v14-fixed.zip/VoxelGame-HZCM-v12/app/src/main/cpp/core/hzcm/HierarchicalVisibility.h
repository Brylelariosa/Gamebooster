#pragma once
// ============================================================================
// HZCM v4 — HierarchicalVisibility.h
// Hierarchical cluster visibility propagation for large render distances.
//
// Key ideas:
//   1. Sky-slab culling: clusters whose Y band is entirely above the
//      surface at the camera's position (no terrain nearby) are skipped.
//   2. Underground culling: clusters more than UNDERGROUND_DROP blocks
//      below the surface AND flagged as fully-opaque-bordered are culled.
//   3. Temporal reuse: visibility is computed once when the camera moves
//      more than 2 blocks, then reused across frames.
//   4. Cluster opacity tracking: each cluster stores whether it is
//      "fully solid" (all boundary voxels opaque). Fully solid clusters
//      that are surrounded on all 6 sides can never be seen — cull them.
//
// Integration:
//   World::update calls HierarchicalVisibility::rebuild() when camera moves.
//   Renderer::renderClusters calls HierarchicalVisibility::isVisible().
//
// CPU cost: O(loadedClusters) once per camera-chunk-change.
// Memory: 1 bit per cluster slot, negligible.
// ============================================================================
#include <cstdint>
#include <cstring>
#include <cmath>
#include <algorithm>
#include "ClusterTypes.h"  // CLUSTER_STACK, CL_SIZE

// Forward declaration (full type in Chunk.h)
class Chunk;
class World;

// ── Per-chunk visibility bitmask ──────────────────────────────────────────────
// One bit per cluster slot (CLUSTER_STACK = 4). Packed into a uint8_t.
struct ChunkVisibility {
    uint8_t mask = 0xFF;  // default: all visible (conservative)

    bool isVisible(int ci) const {
        return (mask >> (uint32_t)ci) & 1u;
    }
    void setVisible(int ci, bool v) {
        if (v) mask |= (1u << ci);
        else   mask &= ~(1u << ci);
    }
    void setAll(bool v) { mask = v ? 0xFF : 0x00; }
};

// ── Main visibility system ────────────────────────────────────────────────────
class HierarchicalVisibility {
public:
    static constexpr int MAX_RADIUS = 210;  // must cover MAX render distance
    static constexpr int GRID       = MAX_RADIUS * 2 + 1;

    static constexpr int UNDERGROUND_DROP = CHUNK_H; // effectively disabled; raise to taste

    HierarchicalVisibility() {
        reset();
    }

    void reset() {
        // Default: everything visible (conservative)
        memset(m_vis, 0xFF, sizeof(m_vis));
        m_camCX = m_camCZ = 0x7FFFFFFF;
        m_camY  = 64.f;
        m_dirty = true;
    }

    // ── Rebuild visibility for the current camera position ────────────────────
    // Call when camera chunk changes. Iterates loaded chunks passed via callback.
    // `surfaceHeight(cx,cz)` returns the world-Y of the surface at chunk (cx,cz).
    // Template allows caller to pass a lambda without virtual overhead.
    template<typename SurfaceFn>
    void rebuild(int camCX, int camCZ, float camY,
                 int renderRadius, SurfaceFn&& surfaceHeight)
    {
        m_camCX = camCX;
        m_camCZ = camCZ;
        m_camY  = camY;

        int camClusterY = (int)(camY / (float)CL_SIZE);
        camClusterY = std::max(0, std::min(camClusterY, CLUSTER_STACK - 1));

        // Clear to visible (conservative default)
        // Only chunks inside renderRadius matter; the renderer frustum-culls rest.
        for (int dz = -renderRadius; dz <= renderRadius; ++dz) {
            for (int dx = -renderRadius; dx <= renderRadius; ++dx) {
                int gx = dx + MAX_RADIUS;
                int gz = dz + MAX_RADIUS;
                if (gx < 0 || gx >= GRID || gz < 0 || gz >= GRID) continue;

                ChunkVisibility& cv = m_vis[gz][gx];
                cv.setAll(true);

                // ── Sky slab culling ─────────────────────────────────────────
                // Clusters fully above (surface + CL_SIZE * 2) are sky and
                // can be marked invisible IF the camera is below them.
                int surf = surfaceHeight(camCX + dx, camCZ + dz);
                int surfCluster = surf / CL_SIZE;

                for (int ci = 0; ci < CLUSTER_STACK; ++ci) {
                    int clusterBaseY = ci * CL_SIZE;
                    int clusterTopY  = clusterBaseY + CL_SIZE;

                    // Sky cluster: entirely above surface + margin AND above camera
                    bool isSkyCluster = (clusterBaseY > surf + CL_SIZE * 2)
                                     && (clusterBaseY > (int)camY + CL_SIZE);
                    if (isSkyCluster) {
                        cv.setVisible(ci, false);
                        continue;
                    }

                    // Underground culling:
                    // If the cluster top is more than UNDERGROUND_DROP below the
                    // camera AND more than UNDERGROUND_DROP below the surface,
                    // it is deeply buried — cull unless within 2 chunks of camera.
                    int chebyshev = std::max(std::abs(dx), std::abs(dz));
                    if (chebyshev > 2) {
                        bool deepUnderSurface = (clusterTopY < surf - UNDERGROUND_DROP);
                        bool deepUnderCamera  = (clusterTopY < (int)camY - UNDERGROUND_DROP);
                        if (deepUnderSurface && deepUnderCamera) {
                            cv.setVisible(ci, false);
                        }
                    }
                }
            }
        }

        m_dirty = false;
    }

    // ── Visibility query (render hot path — must be fast) ─────────────────────
    bool isVisible(int cx, int cz, int ci) const {
        int gx = (cx - m_camCX) + MAX_RADIUS;
        int gz = (cz - m_camCZ) + MAX_RADIUS;
        if ((unsigned)gx >= (unsigned)GRID ||
            (unsigned)gz >= (unsigned)GRID) return false;
        return m_vis[gz][gx].isVisible(ci);
    }

    // Convenience: is any cluster in this chunk visible?
    bool isChunkVisible(int cx, int cz) const {
        int gx = (cx - m_camCX) + MAX_RADIUS;
        int gz = (cz - m_camCZ) + MAX_RADIUS;
        if ((unsigned)gx >= (unsigned)GRID ||
            (unsigned)gz >= (unsigned)GRID) return false;
        return m_vis[gz][gx].mask != 0;
    }

    bool needsRebuild() const { return m_dirty; }
    void markDirty()          { m_dirty = true; }

    int  camCX() const { return m_camCX; }
    int  camCZ() const { return m_camCZ; }

private:
    // 2D grid indexed [z][x], each holding per-cluster visibility bits.
    // GRID × GRID × 1 byte = 421 × 421 × 1 = ~177 KB.
    ChunkVisibility m_vis[GRID][GRID];

    int   m_camCX = 0, m_camCZ = 0;
    float m_camY  = 64.f;
    bool  m_dirty = true;
};
