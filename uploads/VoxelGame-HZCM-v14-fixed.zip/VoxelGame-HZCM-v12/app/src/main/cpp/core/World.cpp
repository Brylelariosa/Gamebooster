// ============================================================================
// HZCM v4 — World.cpp
// ============================================================================
#include "World.h"
#include <android/log.h>
#include <algorithm>
#include <cmath>
#include <climits>
#include <cstring>

#define TAG  "HZCMWorld"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

// ─────────────────────────────────────────────────────────────────────────────
World::World() : m_noise(0) {}

World::~World() {
    m_jobQueue.requestStop();
    for (auto& t : m_workers)
        if (t.joinable()) t.join();
}

// ── Worker main loop ──────────────────────────────────────────────────────────
void World::workerLoop() {
    WorldJob job;
    // popWait blocks up to 20 ms then retries; returns false only when
    // the queue is stopped AND empty — our exit condition.
    while (m_jobQueue.popWait(job, 20)) {
        executeJob(job);
    }
}

// ── Job dispatcher ─────────────────────────────────────────────────────────────
void World::executeJob(const WorldJob& job) {
    switch (job.kind) {
        case JobKind::CHUNK_BUILD:
            workerChunkBuild(job.chunk);
            break;
        case JobKind::CLUSTER_REBUILD:
            workerClusterRebuild(job.chunk, job.ci);
            break;
        case JobKind::NEIGHBOUR_FLUSH:
            workerNeighbourFlush(job.flushCX, job.flushCZ);
            break;
    }
}

// ── Enqueue helpers ────────────────────────────────────────────────────────────
void World::enqueueChunkBuild(Chunk* chunk) {
    WorldJob job{};
    job.kind  = JobKind::CHUNK_BUILD;
    job.world = this;
    job.chunk = chunk;
    job.ci    = -1;
    if (!m_jobQueue.push(job)) {
        // Queue full — defer to retry queue instead of dropping.
        // drainRetryQueue() will re-attempt this job at the start of the
        // next GL-thread update() call.
        m_overflowCount.fetch_add(1, std::memory_order_relaxed);
        std::lock_guard<std::mutex> lk(m_retryMtx);
        m_retryQueue.push_back(job);
        m_retryQueueSize.store((int)m_retryQueue.size(),
                               std::memory_order_relaxed);
        LOGI("CHUNK_BUILD deferred to retry queue (%d,%d) [overflow=%d]",
             chunk->cx, chunk->cz,
             m_overflowCount.load(std::memory_order_relaxed));
    }
}

void World::enqueueClusterRebuild(Chunk* chunk, int ci) {
    WorldJob job{};
    job.kind  = JobKind::CLUSTER_REBUILD;
    job.world = this;
    job.chunk = chunk;
    job.ci    = ci;
    if (!m_jobQueue.push(job)) {
        m_overflowCount.fetch_add(1, std::memory_order_relaxed);
        std::lock_guard<std::mutex> lk(m_retryMtx);
        m_retryQueue.push_back(job);
        m_retryQueueSize.store((int)m_retryQueue.size(),
                               std::memory_order_relaxed);
    }
}

void World::enqueueNeighbourFlush(int cx, int cz) {
    WorldJob job{};
    job.kind    = JobKind::NEIGHBOUR_FLUSH;
    job.world   = this;
    job.chunk   = nullptr;
    job.ci      = -1;
    job.flushCX = cx;
    job.flushCZ = cz;
    if (!m_jobQueue.push(job)) {
        m_overflowCount.fetch_add(1, std::memory_order_relaxed);
        std::lock_guard<std::mutex> lk(m_retryMtx);
        m_retryQueue.push_back(job);
        m_retryQueueSize.store((int)m_retryQueue.size(),
                               std::memory_order_relaxed);
    }
}

// ── Worker implementations ────────────────────────────────────────────────────

void World::workerChunkBuild(Chunk* chunk) {
    // Guard: if chunk was evicted before we even started, skip entirely
    if (chunk->evicted.load(std::memory_order_acquire)) return;
    chunk->inFlight.fetch_add(1, std::memory_order_acquire);

    int cx = chunk->cx, cz = chunk->cz;

    // BUG FIXED (v10 → v11): workerNeighbourFlush can now enqueue a
    // CHUNK_BUILD for a neighbour that is generated-but-not-yet-meshed.
    // Guard against running generate() a second time — terrain is already
    // correct; we only need the mesh step.
    if (!chunk->generated.load(std::memory_order_acquire)) {
        // Generate terrain voxels
        chunk->generate(m_noise);

        // Re-check eviction: might have been evicted during generate()
        if (chunk->evicted.load(std::memory_order_acquire)) {
            chunk->inFlight.fetch_sub(1, std::memory_order_release);
            return;
        }
    }

    // Grab neighbour pointers under shared lock
    const Chunk *nx, *px, *nz, *pz;
    {
        std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);
        nx = getChunk(cx-1, cz); px = getChunk(cx+1, cz);
        nz = getChunk(cx, cz-1); pz = getChunk(cx, cz+1);
    }

    // 3. Mesh all 4 clusters
    for (int ci = 0; ci < CLUSTER_STACK; ++ci)
        chunk->buildClusterMesh(ci, nx, px, nz, pz);

    // Push in REVERSE order so that within a single chunk, ci=0 (ground)
    // is processed before ci=3 (tree-tops) by the LIFO iteration in updateGPU.
    // FIX v13: stamp chebDist so updateGPU can sort the queue nearest-first
    // across different chunks.  Workers use the atomic camera snapshot — no lock.
    {
        int ccx = m_camCXAtomic.load(std::memory_order_relaxed);
        int ccz = m_camCZAtomic.load(std::memory_order_relaxed);
        int dist = std::max(std::abs(chunk->cx - ccx),
                            std::abs(chunk->cz - ccz));
        std::unique_lock<std::mutex> ulk(m_uploadMtx);
        for (int ci = CLUSTER_STACK - 1; ci >= 0; --ci)
            m_uploadQueue.push_back({ chunk, ci, chunk->clusterDirtyGen[ci], dist });
    }

    chunk->inFlight.fetch_sub(1, std::memory_order_release);

    // ── Race-condition guard ────────────────────────────────────────────────
    // If any neighbour that was null when we grabbed pointers above has since
    // generated, our border clusters used BLOCK_AIR for that side and are stale.
    // Enqueue CLUSTER_REBUILD for every affected cluster so the border faces
    // are corrected.  workerNeighbourFlush only triggers on READY/MESHED
    // neighbours, so this self-check is the only way to catch the race where
    // B completes and calls workerNeighbourFlush while A's clusters are DIRTY.
    {
        const Chunk *nx2, *px2, *nz2, *pz2;
        {
            std::shared_lock<std::shared_mutex> rlk2(m_chunksMtx);
            nx2 = getChunk(cx-1, cz); px2 = getChunk(cx+1, cz);
            nz2 = getChunk(cx, cz-1); pz2 = getChunk(cx, cz+1);
        }
        bool stale =
            (nx2 && nx2->generated.load(std::memory_order_acquire) && !nx) ||
            (px2 && px2->generated.load(std::memory_order_acquire) && !px) ||
            (nz2 && nz2->generated.load(std::memory_order_acquire) && !nz) ||
            (pz2 && pz2->generated.load(std::memory_order_acquire) && !pz);
        if (stale) {
            for (int ci2 = 0; ci2 < CLUSTER_STACK; ++ci2)
                enqueueClusterRebuild(chunk, ci2);
        }
    }

    // Remesh border clusters of existing neighbours
    workerNeighbourFlush(cx, cz);
}

void World::workerClusterRebuild(Chunk* chunk, int ci) {
    if (chunk->evicted.load(std::memory_order_acquire)) return;
    chunk->inFlight.fetch_add(1, std::memory_order_acquire);

    int cx = chunk->cx, cz = chunk->cz;
    const Chunk *nx, *px, *nz, *pz;
    {
        std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);
        nx = getChunk(cx-1, cz); px = getChunk(cx+1, cz);
        nz = getChunk(cx, cz-1); pz = getChunk(cx, cz+1);
    }
    chunk->buildClusterMesh(ci, nx, px, nz, pz);

    if (!chunk->evicted.load(std::memory_order_acquire)) {
        int ccx = m_camCXAtomic.load(std::memory_order_relaxed);
        int ccz = m_camCZAtomic.load(std::memory_order_relaxed);
        int dist = std::max(std::abs(chunk->cx - ccx),
                            std::abs(chunk->cz - ccz));
        std::unique_lock<std::mutex> ulk(m_uploadMtx);
        m_uploadQueue.push_back({ chunk, ci, chunk->clusterDirtyGen[ci], dist });
    }

    chunk->inFlight.fetch_sub(1, std::memory_order_release);
}

void World::workerNeighbourFlush(int cx, int cz) {
    // BUG FIXED (v10 → v11): old code only re-meshed neighbours in READY or
    // MESHED state.  A neighbour whose CHUNK_BUILD job had completed generate()
    // but not yet buildClusterMesh() — cluster state = DIRTY — was silently
    // skipped.  In that narrow window, neither this flush nor the neighbour's
    // own stale-check re-queued the rebuild, producing a permanent seam on the
    // shared border.
    //
    // Fix:  Collect two sets —
    //   • remesh: clusters already READY/MESHED that need a border correction.
    //   • initMesh: generated neighbours with ALL clusters still DIRTY/EMPTY,
    //     meaning their first full mesh hasn't happened yet.  Enqueue a
    //     CHUNK_BUILD for them so they pick up the now-generated neighbour
    //     (us) during their own mesh pass.  workerChunkBuild skips generate()
    //     if `generated` is already true, so this is safe against double-gen.
    static const int dirs[4][2] = {{-1,0},{1,0},{0,-1},{0,1}};
    std::vector<std::pair<Chunk*,int>> remesh;
    std::vector<Chunk*>                initMesh;
    {
        std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);
        for (auto& d : dirs) {
            Chunk* nb = getChunk(cx + d[0], cz + d[1]);
            if (!nb || !nb->generated.load(std::memory_order_acquire)) continue;

            bool anyMeshed = false;
            for (int c2 = 0; c2 < CLUSTER_STACK; ++c2) {
                auto st = nb->clusterState[c2].load(std::memory_order_acquire);
                if (st == ClusterState::READY || st == ClusterState::MESHED) {
                    remesh.push_back({nb, c2});
                    anyMeshed = true;
                }
            }
            // All clusters are DIRTY/EMPTY but terrain is generated — the
            // neighbour's initial mesh is in-flight or hasn't been enqueued yet.
            // Trigger a build so it meshes with correct border data.
            if (!anyMeshed && !nb->evicted.load(std::memory_order_acquire)) {
                initMesh.push_back(nb);
            }
        }
    }
    for (auto& [nb, c2] : remesh)
        enqueueClusterRebuild(nb, c2);
    for (Chunk* nb : initMesh)
        enqueueChunkBuild(nb);
}

// ── Init ───────────────────────────────────────────────────────────────────────
void World::init(int seed) {
    m_noise = Noise(seed);

    {
        std::unique_lock<std::shared_mutex> wlk(m_chunksMtx);
        m_chunks.clear();
    }
    m_submitted.clear();
    m_pendingCandidates.clear();
    m_candidateIdx = 0;
    m_lastCamCX = INT_MIN;
    m_lastCamCZ = INT_MIN;
    m_lastRdGen = 0;

    int hw       = (int)std::thread::hardware_concurrency();
    // Allow up to 4 worker threads on devices with enough cores.
    // The extra thread significantly improves drain rate at RD≥12 where
    // the queue can hold hundreds of concurrent CLUSTER_REBUILD jobs.
    int nThreads = std::max(2, std::min(4, hw - 1));
    LOGI("Starting %d worker threads (hw=%d)", nThreads, hw);
    for (int i = 0; i < nThreads; ++i)
        m_workers.emplace_back([this] { workerLoop(); });

    // Prime initial area
    update(0.f, 0.f, 64.f, 0.f, 0.f, 0.f, 1.f, 0.016f);
    LOGI("World init done (render distance=%d)", m_renderDist.getDistance());
}

// ── Effective radius ──────────────────────────────────────────────────────────
// FIX v13: Thermal scaling REMOVED from effective radius.
//
// Old behaviour: m_effectiveRadius = max(2, (int)(requested × radiusScale()))
//   • WARM  → radius shrinks to 75% of requested
//   • HOT   → radius shrinks to 50%
//   • CRITICAL → radius shrinks to 30%
//   Combined with slow rebuild/upload budgets, this caused chunks at
//   render distances ≥ 8 to never load: the thermally-reduced radius
//   shrank the candidate list while the submission loop still consumed
//   the full budget on empty iterations.
//
// New behaviour: m_effectiveRadius = requested (always).
//   Thermal throttling is applied ONLY to:
//     • maxNew      (submission budget per frame, via thermalScale factor)
//     • upload budget (maxUploadBudget() × rdScale in updateGPU)
//     • rebuild budget (maxRebuildBudget() guards workerClusterRebuild paths)
//   This preserves full world coverage at any render distance while still
//   slowing down loading speed on hot devices to avoid overheating.
void World::refreshEffectiveRadius() {
    m_effectiveRadius = m_renderDist.getDistance();
}

// ── Retry queue drain ──────────────────────────────────────────────────────────
// Called once per frame at the top of update() before new chunk submissions.
// Attempts to push previously-dropped jobs back into m_jobQueue now that
// workers may have drained some capacity.
//
// Design notes:
//   • Jobs are eviction-checked before push: if a chunk was evicted while
//     sitting in the retry queue, it is discarded (no use re-meshing it).
//   • A single-pass strategy is used — we don't loop until empty.  If the
//     queue is still too full for some retries, they stay in m_retryQueue and
//     are re-attempted next frame.  This prevents infinite spinning on a
//     sustained-full queue.
//   • m_retryQueue is a std::vector accessed under m_retryMtx.  We swap it
//     out under the lock (O(1)) then release the lock before doing any pushes
//     so workers don't contend on m_retryMtx during drain.
void World::drainRetryQueue() {
    std::vector<WorldJob> snapshot;
    {
        std::lock_guard<std::mutex> lk(m_retryMtx);
        if (m_retryQueue.empty()) return;
        snapshot.swap(m_retryQueue);
        m_retryQueueSize.store(0, std::memory_order_relaxed);
    }

    int pushed = 0, dropped = 0, requeued = 0;
    for (auto& job : snapshot) {
        // Skip evicted chunks — no point retrying a dead chunk
        if (job.chunk && job.chunk->evicted.load(std::memory_order_acquire)) {
            ++dropped;
            continue;
        }
        if (m_jobQueue.push(job)) {
            ++pushed;
        } else {
            // Queue still full — put back for next frame
            std::lock_guard<std::mutex> lk(m_retryMtx);
            m_retryQueue.push_back(job);
            ++requeued;
        }
    }

    {
        std::lock_guard<std::mutex> lk(m_retryMtx);
        m_retryQueueSize.store((int)m_retryQueue.size(),
                               std::memory_order_relaxed);
    }

    if (pushed > 0 || requeued > 0)
        LOGI("RetryQueue drain: pushed=%d dropped=%d requeued=%d", pushed, dropped, requeued);
}

// ── Per-frame update ───────────────────────────────────────────────────────────
void World::update(float camX, float camZ, float camY,
                    float velX, float velZ,
                    float fwdX, float fwdZ, float dt)
{
    ++m_frameCount;

    m_thermal.update(dt);
    m_scheduler.update(camX, camZ, camY, velX, velZ, fwdX, fwdZ);

    // ── Drain deferred retry queue first ──────────────────────────────────────
    // Any CHUNK_BUILD / CLUSTER_REBUILD / NEIGHBOUR_FLUSH jobs that failed to
    // push last frame (queue was full) are retried here before new submissions,
    // preserving priority ordering and preventing permanent border seams.
    drainRetryQueue();

    bool rdChanged = m_renderDist.pollChanged(m_lastRdGen);
    refreshEffectiveRadius();

    // FIX v13: loadR / unloadR use the full requested radii — no thermal
    // reduction.  `scale` is retained for the per-frame debug log only.
    // Thermal throttling operates exclusively on the submission/upload/rebuild
    // budgets computed later in this function and in updateGPU().
    float scale = m_thermal.radiusScale();   // informational — NOT applied to radii
    auto  radii = m_renderDist.getRadii();
    int loadR   = radii.load;    // = requestedRD + 1  (neighbours for seam meshing)
    int unloadR = radii.unload;  // = requestedRD + 4  (hysteresis avoids thrashing)

    int camCX = (int)floorf(camX / (float)CHUNK_W);
    int camCZ = (int)floorf(camZ / (float)CHUNK_D);
    bool camMoved = (camCX != m_lastCamCX || camCZ != m_lastCamCZ);

    // Keep atomic snapshot current — worker threads read these to stamp
    // chebDist on UploadTasks without acquiring any lock.
    m_camCXAtomic.store(camCX, std::memory_order_relaxed);
    m_camCZAtomic.store(camCZ, std::memory_order_relaxed);

    // ── Unload ────────────────────────────────────────────────────────────────
    if (camMoved || rdChanged) {
        std::vector<std::pair<ChunkKey, std::unique_ptr<Chunk>>> evicted;
        {
            std::unique_lock<std::shared_mutex> wlk(m_chunksMtx);
            for (auto it = m_chunks.begin(); it != m_chunks.end(); ) {
                int dx = std::abs(it->first.cx - camCX);
                int dz = std::abs(it->first.cz - camCZ);
                if (dx > unloadR || dz > unloadR) {
                    evictChunk(it->second.get());           // mark evicted + free GPU
                    m_submitted.erase({it->first.cx, it->first.cz});
                    evicted.push_back({it->first, std::move(it->second)});
                    it = m_chunks.erase(it);
                } else {
                    ++it;
                }
            }

            // BUG FIXED (v10 → v11): On render-distance change, also scrub any
            // m_submitted entries whose chunk is no longer in m_chunks.  This
            // can happen when the queue-full rollback path removes a chunk from
            // m_chunks between a rdChanged and its corresponding eviction pass
            // (the rollback does not erase from m_submitted because the entry
            // was never inserted, but a pathological multi-frame sequence could
            // leave the set pointing at a dead key).  The check is cheap and
            // makes the submitted set provably consistent after every RD event.
            if (rdChanged) {
                for (auto sit = m_submitted.begin(); sit != m_submitted.end(); ) {
                    if (m_chunks.find({sit->cx, sit->cz}) == m_chunks.end())
                        sit = m_submitted.erase(sit);
                    else
                        ++sit;
                }
            }
        }
        // Move evicted chunks to graveyard (deferred deletion — workers may still be reading)
        {
            std::lock_guard<std::mutex> glk(m_graveyardMtx);
            for (auto& [key, ptr] : evicted) {
                m_graveyard.push_back({ std::move(ptr), 4 }); // wait 4 frames
                enqueueNeighbourFlush(key.cx, key.cz);
            }
        }
    }

    // ── Rebuild sorted candidate list when necessary ───────────────────────────
    // Rebuild triggers:
    //   1. camMoved  — player entered a new chunk; frontier has shifted.
    //   2. rdChanged — render distance changed; candidate grid resized.
    //   3. missingNearbyChunk (stall-recovery) — candidates exhausted AND at
    //      least one position within loadR is absent from m_chunks.
    //
    // FIX v14: replaced the broken submittedDeficit check
    //   ((int)m_submitted.size() < expectedFull)
    // with a direct O(N) scan of m_chunks.
    //
    // Why the old check was wrong:
    //   m_submitted is a global accumulated set.  After the player's first
    //   camera-chunk move the set grows beyond expectedFull because the
    //   eviction hysteresis keeps (2*(RD+4)+1)^2 chunks resident while
    //   expectedFull = (2*(RD+1)+1)^2.  submittedDeficit therefore became
    //   permanently false after the very first move, disabling stall-recovery
    //   for the rest of the session.  The "one RD change helps" symptom
    //   followed directly: raising RD temporarily lifted expectedFull above
    //   m_submitted.size() for one load cycle, then the set outpaced it again.
    //
    // Why the new check is correct:
    //   m_chunks is the ground truth for what is actually loaded.  A position
    //   absent from m_chunks is genuinely missing regardless of what
    //   m_submitted says.  The scan is bounded by (2*loadR+1)^2 entries
    //   (361 at RD=8, 1225 at RD=16), runs only when candidates are exhausted
    //   AND the camera has not moved, and early-exits on the first missing
    //   entry — so a fully-loaded stationary player pays near-zero cost.
    bool candidatesExhausted = (m_candidateIdx >= (int)m_pendingCandidates.size());

    // ── Periodic full-radius missing-chunk scan ───────────────────────────────
    //
    // ROOT BUG FIX (v12 → v14):
    //
    // OLD code ran this scan ONLY when:
    //   candidatesExhausted && !camMoved && !rdChanged
    //
    // While the player is exploring, camMoved=true every frame, so the scan
    // NEVER ran.  Chunks starved by the (now-removed) forward-bias sort were
    // perpetually deferred and holes were never detected.
    //
    // NEW behaviour: scan runs every MISSING_SCAN_INTERVAL frames regardless
    // of movement, PLUS the original "exhausted + stationary" fast path.
    //   • Full-radius square (not Euclidean circle) to match buildCandidates.
    //   • Counts total positions and missing positions for debug telemetry.
    //   • Early-exit removed: scan the whole radius to get accurate missing count.
    //   • If any chunk is missing, forces a candidate rebuild to re-enqueue it.
    //
    // Performance: (2*loadR+1)^2 unordered_map lookups.
    //   RD=8  → 361 lookups,  RD=16 → 1225 lookups.
    //   Each lookup is O(1).  At 120-frame interval (~2 s), cost is negligible.
    static constexpr int MISSING_SCAN_INTERVAL = 120;  // ~2 s at 60 fps
    bool doPeriodicScan = (m_frameCount % MISSING_SCAN_INTERVAL == 1);

    bool missingNearbyChunk = false;
    int  scanTotalInRadius  = 0;
    int  scanMissingCount   = 0;

    if ((candidatesExhausted && !camMoved && !rdChanged) || doPeriodicScan) {
        std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);
        for (int dz = -loadR; dz <= loadR; ++dz) {
            for (int dx = -loadR; dx <= loadR; ++dx) {
                ++scanTotalInRadius;
                if (m_chunks.find({camCX + dx, camCZ + dz}) == m_chunks.end()) {
                    ++scanMissingCount;
                    missingNearbyChunk = true;
                    // Do NOT early-exit: continue scanning for accurate count.
                }
            }
        }
    }

    // Update diagnostic counters (read by getDebugStats / HUD).
    m_lastTotalInRadius = scanTotalInRadius;
    m_lastMissingCount  = scanMissingCount;

    // ── Stranded-chunk recovery ───────────────────────────────────────────────
    // Runs every MISSING_SCAN_INTERVAL frames alongside the missing-chunk scan.
    // Detects chunks that ARE in m_chunks (so the missing-chunk scan won't catch
    // them) but whose build job was lost: generated=false AND inFlight=0 means
    // no worker is processing the chunk right now.
    //
    // Safe to re-enqueue: workerChunkBuild checks generated.load() before
    // running generate(), so a duplicate CHUNK_BUILD is a no-op if the chunk
    // already completed between the scan and the worker execution.
    if (doPeriodicScan) {
        std::vector<Chunk*> stranded;
        {
            std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);
            for (auto& kv : m_chunks) {
                Chunk* ch = kv.second.get();
                if (!ch->evicted  .load(std::memory_order_acquire)
                    && !ch->generated.load(std::memory_order_acquire)
                    &&   ch->inFlight .load(std::memory_order_acquire) == 0)
                {
                    stranded.push_back(ch);
                }
            }
        }
        // Enqueue outside the shared lock so workers can run concurrently.
        for (Chunk* ch : stranded)
            enqueueChunkBuild(ch);

        m_lastStrandedCount = (int)stranded.size();
        if (!stranded.empty()) {
            LOGI("Stranded-chunk recovery: re-queued=%d frame=%d RD=%d",
                 (int)stranded.size(), m_frameCount,
                 m_renderDist.getDistance());
        }
    }

    bool needRebuild = camMoved || rdChanged || missingNearbyChunk;

    if (needRebuild) {
        m_lastCamCX = camCX;
        m_lastCamCZ = camCZ;
        ++m_candidateRebuildCount;
        m_pendingCandidates.clear();
        StreamScheduler::buildCandidates(camCX, camCZ, 0, loadR, m_pendingCandidates);

        // Strip already-submitted chunks so every slot represents genuine
        // unsubmitted work.  The duplicate guard inside the submission loop
        // is kept as a safety net only.
        {
            auto newEnd = std::remove_if(
                m_pendingCandidates.begin(), m_pendingCandidates.end(),
                [this](const ChunkPriority& cp) {
                    return m_submitted.count({cp.cx, cp.cz}) != 0;
                });
            m_pendingCandidates.erase(newEnd, m_pendingCandidates.end());
        }

        m_scheduler.sortByPriority(m_pendingCandidates);
        m_candidateIdx = 0;
        m_visibility.markDirty();

        if (missingNearbyChunk) {
            LOGI("Missing-chunk recovery rebuild: "
                 "totalInRadius=%d missing=%d submitted=%u candidates=%zu "
                 "camCX=%d camCZ=%d RD=%d rebuilds=%d",
                 scanTotalInRadius, scanMissingCount,
                 (unsigned)m_submitted.size(),
                 m_pendingCandidates.size(),
                 camCX, camCZ,
                 m_renderDist.getDistance(),
                 m_candidateRebuildCount);
        }
    }

    // ── Submit unsubmitted chunks every frame (not only on camera move) ────────
    // This ensures a stationary player at any RD still loads all chunks.
    // maxNew scales with render distance so large RD loads faster.
    // Near chunks always have highest priority (sorted above).
    //
    // CRITICAL: cap maxNew to available queue space and only insert into
    // m_submitted AFTER a successful push.  The old code did:
    //
    //   m_submitted.insert(key);   <- always
    //   m_chunks[key] = ...;       <- always
    //   enqueueChunkBuild(ptr);    <- silently dropped when queue full
    //
    // A dropped push left a zombie chunk: in m_submitted (never retried) and
    // in m_chunks (DIRTY forever). With RD>=16 the 1024-slot ring filled in
    // ~16 frames causing slow loading and terrain missing after RD changes.
    {
        // ── Dynamic submission budget ─────────────────────────────────────────
        // Goal: process one entire outer-ring shell worth of new chunks in
        // roughly 4–8 frames regardless of render distance.
        //
        //   baseNew = max(8, 2*R) scaled by thermal state
        //     RD=8  → 16/frame
        //     RD=12 → 24/frame
        //     RD=16 → 32/frame
        //
        // NOTE: Do NOT add a "far-ring throttle" that skips far candidates
        // while advancing candidateIdx.  Such a throttle causes a permanent
        // stall: the skipped positions are never inserted into m_submitted,
        // so they represent genuine unsubmitted work, but candidateIdx has
        // moved past them.  The candidate list only rebuilds on camMoved or
        // rdChanged, so a stationary player stalls permanently and an
        // exploring player stalls between moves.  Upload-queue priority
        // (distance-sorted in updateGPU) already ensures nearby chunks
        // upload before far ones — no submission-side throttle is needed.
        int thermalScale = m_thermal.maxRebuildBudget(); // 8/4/2/1 per state
        int baseNew = std::max(8, 2 * m_effectiveRadius);
        baseNew = std::max(8, baseNew * thermalScale / 8);

        int queueFreeNow = (int)m_jobQueue.approximateFree()
                         - 128;  // headroom for secondary jobs
        int maxNew = std::min(baseNew, std::max(0, queueFreeNow));

        int submitted    = 0;
        int skipped      = 0;
        bool hadOverflow = false;

        // FIX v14: do NOT pre-increment m_candidateIdx before resolving the
        // slot.  Old pattern advanced the index unconditionally then skipped
        // the slot on duplicate — permanently losing that candidate position.
        // New invariant: m_candidateIdx advances ONLY after the slot is fully
        // committed (submitted to ring + inserted into m_submitted) or
        // explicitly skipped as a known duplicate.  On overflow the index stays
        // put so the same slot is retried next frame.
        while (m_candidateIdx < (int)m_pendingCandidates.size()
               && submitted < maxNew
               && !hadOverflow)
        {
            // Peek — do NOT advance yet.
            const auto& cp = m_pendingCandidates[m_candidateIdx];
            ChunkKey key{cp.cx, cp.cz};

            // Safety-net duplicate guard.  The pre-filter on rebuild strips all
            // currently-submitted entries, so this fires only in rare edge cases
            // (e.g. a key re-submitted between rebuild and loop iteration).
            // When it does fire we advance past the slot — the chunk is already
            // handled, no work is lost.
            if (m_submitted.count(key)) {
                ++m_candidateIdx;   // advance: slot is handled, not lost
                ++skipped;
                continue;
            }

            Chunk* ptr;
            {
                std::unique_lock<std::shared_mutex> wlk(m_chunksMtx);
                auto ch = std::make_unique<Chunk>(cp.cx, cp.cz);
                ptr = ch.get();
                m_chunks[key] = std::move(ch);
            }

            // Push inline so we can react to failure before touching
            // m_submitted or advancing m_candidateIdx.
            WorldJob job{};
            job.kind  = JobKind::CHUNK_BUILD;
            job.world = this;
            job.chunk = ptr;
            job.ci    = -1;
            if (!m_jobQueue.push(job)) {
                // Queue unexpectedly full despite the headroom cap.
                // Undo the allocation.  Do NOT advance m_candidateIdx —
                // this exact slot will be retried next frame.
                {
                    std::unique_lock<std::shared_mutex> wlk(m_chunksMtx);
                    m_chunks.erase(key);
                }
                m_overflowCount.fetch_add(1, std::memory_order_relaxed);
                hadOverflow = true;
                LOGI("Submission overflow at candidate %d (queue≈%u free≈%d) RD=%d",
                     m_candidateIdx,
                     m_jobQueue.approximateSize(),
                     (int)m_jobQueue.approximateFree(),
                     m_renderDist.getDistance());
                break;
            }

            // Job is safely in the ring — now commit: mark submitted and advance.
            m_submitted.insert(key);
            ++m_candidateIdx;
            ++submitted;
        }

        // ── Periodic debug log ────────────────────────────────────────────────
        // Every 60 frames (~1 s at 60 fps): dump all streaming telemetry to
        // logcat so that RD-related stalls can be diagnosed without a debugger.
        if (m_frameCount % 60 == 0) {
            size_t uploadBacklog;
            {
                std::unique_lock<std::mutex> ulk(m_uploadMtx);
                uploadBacklog = m_uploadQueue.size();
            }
            // Compute in-radius count for this log tick without a full scan
            // (m_lastTotalInRadius / m_lastMissingCount come from the periodic
            // scan at MISSING_SCAN_INTERVAL; zero between scans is expected).
            LOGI("[ HZCM Stream v14 ] "
                 "frame=%d RD=%d effectiveR=%d | "
                 "queueSize=%u/%u queueFree=%d overflowTotal=%d retryQ=%d | "
                 "submitted=%u candidates=%zu candidateIdx=%zu "
                 "rebuilds=%d skipped=%d | "
                 "totalInRadius=%d missing=%d stranded=%d "
                 "missingNow=%s | "
                 "uploadBacklog=%zu workers=%d visible=%d",
                 m_frameCount,
                 m_renderDist.getDistance(), m_effectiveRadius,
                 m_jobQueue.approximateSize(), JOB_RING_CAPACITY,
                 (int)m_jobQueue.approximateFree(),
                 m_overflowCount.load(std::memory_order_relaxed),
                 m_retryQueueSize.load(std::memory_order_relaxed),
                 (unsigned)m_submitted.size(),
                 m_pendingCandidates.size(), (size_t)m_candidateIdx,
                 m_candidateRebuildCount,
                 skipped,
                 m_lastTotalInRadius, m_lastMissingCount, m_lastStrandedCount,
                 missingNearbyChunk ? "YES" : "no",
                 uploadBacklog,
                 (int)m_workers.size(),
                 m_lastVisibleDraws);
        }
    }

    // ── Rebuild HierarchicalVisibility when camera chunk changes ───────────────
    if (m_visibility.needsRebuild()) {
        // BUG FIXED (v11 → v12): old code passed a lambda that called
        // surfaceHeightAt() for every cell in the (2*RD+1)² grid, each
        // acquiring a separate shared_lock on m_chunksMtx.  At RD=200 that
        // is ~163 k lock acquisitions — a 30–100 ms GL-thread stall per
        // camera chunk-move.  The stall also pushed frame times into the
        // ThermalManager's HOT/CRITICAL range, cutting effectiveRadius to
        // 50–60 % and reducing chunk-submission budgets, compounding the
        // loading problem.
        //
        // Fix: snapshot surface heights for ALL loaded chunks under ONE
        // shared lock, then pass a fast hash-map lookup as the callback.
        // The total cost is one lock acquire + one unordered_map fill over
        // the (small) set of actually-loaded chunks, then one lock release.
        std::unordered_map<ChunkKey, int, ChunkKeyHash> surfHeights;
        {
            std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);
            surfHeights.reserve(m_chunks.size());
            for (auto& kv : m_chunks) {
                const Chunk* ch2 = kv.second.get();
                if (!ch2->generated.load(std::memory_order_acquire)) {
                    surfHeights[kv.first] = 40;
                    continue;
                }
                int h = 0;
                for (int y = CHUNK_H - 1; y >= 0; --y) {
                    if (ch2->getBlock(8, y, 8) != BLOCK_AIR) { h = y; break; }
                }
                surfHeights[kv.first] = h;
            }
        }
        m_visibility.rebuild(camCX, camCZ, camY, m_effectiveRadius,
            [&surfHeights](int cx, int cz) -> int {
                auto it = surfHeights.find({cx, cz});
                return it != surfHeights.end() ? it->second : 40;
            });
    }
}

// ── GPU upload ─────────────────────────────────────────────────────────────────
void World::updateGPU() {
    m_mega.beginFrame();

    // ── Tick graveyard — delete chunks whose workers have all finished ─────────
    {
        std::lock_guard<std::mutex> glk(m_graveyardMtx);
        auto it = m_graveyard.begin();
        while (it != m_graveyard.end()) {
            it->frames--;
            // Safe to delete when countdown expired AND no worker is inside it
            if (it->frames <= 0 && it->chunk->inFlight.load(std::memory_order_acquire) == 0) {
                it = m_graveyard.erase(it);   // unique_ptr destructor runs here
            } else {
                ++it;
            }
        }
    }

    // Scale upload budget with render distance.
    //
    // FIX v13 (updated): bumped rdScale denominator from /4 to /3 to keep
    // large render distances from starving nearby chunks.
    //   RD=8..10  → scale=2 → 48 cluster uploads/frame at COOL
    //   RD=12..14 → scale=3 → 72/frame
    //   RD=16+    → scale≥4 → 96+/frame
    // Still applies thermal multiplier so hot devices slow down gracefully.
    int rdScale = std::max(1, m_effectiveRadius / 3);
    int budget  = m_thermal.maxUploadBudget() * CLUSTER_STACK * rdScale;

    std::vector<UploadTask> tasks;
    {
        std::unique_lock<std::mutex> ulk(m_uploadMtx);

        // ── Distance-priority sort (nearest-first) ────────────────────────────
        // Workers complete in thread-schedule order, not proximity order.
        // Without sorting here, far chunks that happen to finish first consume
        // the entire upload budget, leaving nearby chunks invisible for many
        // frames and creating the "big holes near player" symptom.
        //
        // Sort is O(N log N) on the full backlog, done once per frame under the
        // mutex.  At RD=16 the queue peaks at ~1444 entries; std::sort on 1444
        // ints takes <0.1 ms — negligible vs the 16 ms frame budget.
        //
        // Sort: smallest chebDist first (nearest chunks upload first).
        // Secondary key: ci ascending (ci=0 ground before ci=3 sky) so that
        // within the same chunk the lowest cluster uploads first.
        std::sort(m_uploadQueue.begin(), m_uploadQueue.end(),
            [](const UploadTask& a, const UploadTask& b) {
                if (a.chebDist != b.chebDist) return a.chebDist < b.chebDist;
                if (a.chunk    != b.chunk)    return a.chunk    <  b.chunk;
                return a.ci < b.ci;
            });

        // Drain from the FRONT (nearest chunks) up to budget.
        int n = std::min(budget, (int)m_uploadQueue.size());
        if (n > 0) {
            tasks.assign(m_uploadQueue.begin(), m_uploadQueue.begin() + n);
            m_uploadQueue.erase(m_uploadQueue.begin(), m_uploadQueue.begin() + n);
        }
    }

    // Iterate forward — the sort above guarantees ci=0 (ground) before ci=3
    // (sky) within any chunk, and nearest chunks before farther ones across
    // chunks.  The old reverse-iteration trick was a workaround for the LIFO
    // pop; it is no longer needed and was reversed here.
    for (int ti = 0; ti < (int)tasks.size(); ++ti) {
        auto& task = tasks[ti];
        Chunk*   ch = task.chunk;
        int      ci = task.ci;

        // Skip if chunk was evicted while this task was queued
        if (ch->evicted.load(std::memory_order_acquire)) continue;

        // Stale check: cluster was re-dirtied after enqueue
        // A newer CLUSTER_REBUILD will have already re-queued it.
        if (ch->clusterState[ci].load(std::memory_order_acquire) != ClusterState::MESHED)
            continue;
        if (ch->clusterDirtyGen[ci] != task.dirtyGen)
            continue;

        std::lock_guard<std::mutex> lk(ch->clusterMutex[ci]);
        auto& faces  = ch->clusterFaces[ci];
        uint32_t nFaces = (uint32_t)faces.size();

        // Free old GPU slot first
        if (ch->clusterGPUOffset[ci] != MEGA_INVALID) {
            m_mega.free(ch->clusterGPUOffset[ci], ch->clusterFaceCount[ci]);
            ch->clusterGPUOffset[ci] = MEGA_INVALID;
            ch->clusterFaceCount[ci] = 0;
        }

        if (nFaces > 0) {
            uint32_t offset = m_mega.alloc(nFaces);
            if (offset != MEGA_INVALID) {
                if (!m_mega.upload(offset, faces.data(), nFaces)) {
                    // Ring staging full this frame — return to queue for next frame
                    m_mega.free(offset, nFaces);
                    std::unique_lock<std::mutex> ulk(m_uploadMtx);
                    m_uploadQueue.push_back(task);
                    continue;
                }
                ch->clusterGPUOffset[ci] = offset;
                ch->clusterFaceCount[ci] = nFaces;
            } else {
                LOGE("PageAllocator full! used=%u total=%u",
                     m_mega.usedFaces(), m_mega.totalFaces());
            }
        }

        faces.clear();
        faces.shrink_to_fit();
        ch->clusterState[ci].store(ClusterState::READY, std::memory_order_release);

        // Track first-time uploads per cluster.  uploadedClusterCount is
        // GL-thread-only so no atomic/lock needed.  We only increment when
        // the cluster had no prior GPU allocation (MEGA_INVALID before alloc),
        // meaning this is the very first successful upload for this cluster.
        // Once uploadedClusterCount == CLUSTER_STACK the chunk becomes visible.
        if (ch->uploadedClusterCount < CLUSTER_STACK) {
            // We freed the old slot and re-allocated above; if the new offset
            // is valid OR faces were zero (empty cluster, offset stays INVALID
            // but cluster is legitimately empty), count it as "first uploaded".
            // The "was MEGA_INVALID before this task ran" check: we can't read
            // that retroactively, so instead we count every cluster we process
            // that hasn't been counted yet.  Use the cluster index as a one-bit
            // seen-flag via a bitmask stored on the chunk.
            if (!(ch->clusterFirstUploadMask & (1u << ci))) {
                ch->clusterFirstUploadMask |= (1u << ci);
                ++ch->uploadedClusterCount;
            }
        }
    }

    // One glMapBufferRange + fence for all staged uploads
    m_mega.flushUploads();
}

// ── Gather visible clusters + sorted draw ─────────────────────────────────────
void World::gatherAndDraw(const Frustum& frustum, GLint originUniformLoc) {
    m_drawBatcher.beginFrame();

    int visible = 0;
    std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);

    for (auto& kv : m_chunks) {
        Chunk* ch = kv.second.get();

        // 1. HierarchicalVisibility chunk-level cull
        if (!m_visibility.isChunkVisible(ch->cx, ch->cz)) continue;

        // 1b. Partial-render guard — FIX v13.
        //
        // OLD behaviour (v12 and earlier):
        //   if (ch->uploadedClusterCount < CLUSTER_STACK) continue;
        //
        //   This hid the ENTIRE chunk until all 4 clusters were uploaded.
        //   At RD≥8 the upload budget is shared across hundreds of chunks.
        //   A nearby chunk with 3/4 clusters uploaded stayed COMPLETELY INVISIBLE
        //   while far-away chunks that happened to finish all 4 uploads first
        //   rendered immediately.  The result: giant missing holes right next to
        //   the player while terrain loads correctly at distance.
        //
        // NEW behaviour:
        //   Render any cluster that has a valid GPU allocation (MEGA_INVALID check
        //   happens per-cluster below).  An incomplete chunk shows partial terrain
        //   (e.g., ground visible, sky-layer not yet uploaded) which is FAR less
        //   jarring than a completely invisible column.
        //
        //   The uploadedClusterCount guard is reduced to only blocking chunks
        //   where NO cluster at all has been uploaded yet (count == 0), which
        //   avoids drawing chunks whose GPU slots are entirely uninitialised.
        if (ch->uploadedClusterCount == 0) continue;

        // 1c. Soft neighbour-generation guard — defers drawing only when a
        // neighbour is ACTIVELY being generated right now (inFlight > 0).
        //
        // BUG FIXED (v11 → v12):
        // The old guard blocked drawing if ANY cardinal neighbour existed in
        // m_chunks but was not yet generated — i.e. was merely QUEUED.
        // With a 1024-slot job ring that stays near-full at moderate/high RD,
        // up to ~1000 chunks are simultaneously "queued but ungenerated".
        // Every chunk adjacent to any of those was permanently invisible,
        // producing the "chunks never appear while exploring" symptom.
        //
        // New rule: only defer while inFlight > 0 on the neighbour, meaning
        // a worker thread is processing it right now.  With at most 3 workers
        // running concurrently, at most 3 chunks have inFlight > 0, so the
        // guard almost never fires.  The brief floating-island faces that may
        // appear between a chunk's first upload and its neighbour's
        // workerNeighbourFlush re-mesh are acceptable vs permanent invisibility.
        {
            static const int CDIRS[4][2] = {{-1,0},{1,0},{0,-1},{0,1}};
            bool waitingForNeighbour = false;
            for (int d = 0; d < 4; ++d) {
                const Chunk* nb = getChunk(ch->cx + CDIRS[d][0],
                                           ch->cz + CDIRS[d][1]);
                // Only block if the neighbour is mid-generation RIGHT NOW.
                // Chunks merely queued (inFlight==0, generated==false) no
                // longer prevent their neighbours from being drawn.
                if (nb && !nb->generated.load(std::memory_order_acquire)
                       &&  nb->inFlight.load(std::memory_order_acquire) > 0) {
                    waitingForNeighbour = true;
                    break;
                }
            }
            if (waitingForNeighbour) continue;
        }

        // 2. Frustum cull
        float mnX, mnY, mnZ, mxX, mxY, mxZ;
        ch->getAABB(mnX, mnY, mnZ, mxX, mxY, mxZ);
        if (!frustum.testAABB({mnX,mnY,mnZ}, {mxX,mxY,mxZ})) continue;

        for (int ci = 0; ci < CLUSTER_STACK; ++ci) {
            // 3. Per-cluster visibility (sky / underground)
            if (!m_visibility.isVisible(ch->cx, ch->cz, ci)) continue;

            // Accept both READY and MESHED: a MESHED cluster is mid-rebuild
            // but its GPU allocation from the previous mesh is still valid —
            // keep drawing old data so the face never vanishes between the
            // "neighbour flush" rebuild and the next GPU upload.
            ClusterState cst = ch->clusterState[ci].load(std::memory_order_acquire);
            if (cst != ClusterState::READY && cst != ClusterState::MESHED)
                continue;

            uint32_t offset = ch->clusterGPUOffset[ci];
            uint32_t count  = ch->clusterFaceCount[ci];
            if (offset == MEGA_INVALID || count == 0) continue;

            m_drawBatcher.submit(
                ch->clusterWorldX(ci),
                ch->clusterWorldY(ci),
                ch->clusterWorldZ(ci),
                offset, count);
            ++visible;
        }
    }
    m_lastVisibleDraws = visible;

    // Sort by mega-offset → sequential VBO reads → driver prefetch wins
    m_drawBatcher.sort();
    m_drawBatcher.issueDraws(originUniformLoc);
}

// ── Evict ─────────────────────────────────────────────────────────────────────
// MUST be called while holding the write lock on m_chunksMtx.
// We mark `evicted` FIRST (so any in-flight worker stops writing),
// release GPU slots, then hand ownership to the graveyard for deferred deletion.
// The unique_ptr is moved out of m_chunks by the caller AFTER this call.
void World::evictChunk(Chunk* chunk) {
    // Signal workers to abandon this chunk immediately
    chunk->evicted.store(true, std::memory_order_release);

    // Release GPU slots (GL thread — safe here)
    for (int ci = 0; ci < CLUSTER_STACK; ++ci) {
        if (chunk->clusterGPUOffset[ci] != MEGA_INVALID) {
            m_mega.free(chunk->clusterGPUOffset[ci], chunk->clusterFaceCount[ci]);
            chunk->clusterGPUOffset[ci] = MEGA_INVALID;
            chunk->clusterFaceCount[ci] = 0;
        }
        chunk->clusterState[ci].store(ClusterState::EMPTY, std::memory_order_release);
    }
}

// ── Surface height (for HierarchicalVisibility) ────────────────────────────────
int World::surfaceHeightAt(int cx, int cz) const {
    // Caller holds no lock — take shared briefly
    std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);
    const Chunk* ch = getChunk(cx, cz);
    if (!ch || !ch->generated.load(std::memory_order_acquire)) return 40;
    for (int y = CHUNK_H - 1; y >= 0; --y)
        if (ch->getBlock(8, y, 8) != BLOCK_AIR) return y;
    return 0;
}

// ── Accessors ─────────────────────────────────────────────────────────────────
Chunk* World::getChunk(int cx, int cz) const {
    auto it = m_chunks.find({cx, cz});
    return it != m_chunks.end() ? it->second.get() : nullptr;
}

uint8_t World::getBlock(int wx, int wy, int wz) const {
    if (wy < 0 || wy >= CHUNK_H) return BLOCK_AIR;
    int cx = (int)floorf((float)wx / CHUNK_W);
    int cz = (int)floorf((float)wz / CHUNK_D);
    int lx = wx - cx * CHUNK_W;
    int lz = wz - cz * CHUNK_D;
    std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);
    const Chunk* ch = getChunk(cx, cz);
    return ch ? ch->getBlock(lx, wy, lz) : BLOCK_AIR;
}

int World::getChunkCount() const {
    std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);
    return (int)m_chunks.size();
}

// ── Debug stats snapshot ───────────────────────────────────────────────────────
// Fills a WorldDebugStats struct with a point-in-time telemetry snapshot.
// Called from Renderer::render() on the GL thread; result forwarded to
// DebugOverlay's thread-safe cache which Java polls at ~4 Hz.
WorldDebugStats World::getDebugStats(float fps) {
    WorldDebugStats s{};

    s.fps             = fps;
    s.requestedRD     = m_renderDist.getDistance();
    s.effectiveRadius = m_effectiveRadius;   // = requestedRD after v13 fix

    // Thermal — informational (no longer affects radius after v13 fix)
    s.thermalScale    = m_thermal.radiusScale();
    strncpy(s.thermalState, m_thermal.stateString(),
            sizeof(s.thermalState) - 1);
    s.thermalState[sizeof(s.thermalState) - 1] = '\0';
    s.thermalPressure = m_thermal.thermalPressure();
    s.thermalEmaMs    = m_thermal.frameEmaMs();

    // Job queue
    s.queueSize      = m_jobQueue.approximateSize();
    s.queueFree      = m_jobQueue.approximateFree();
    s.queueCapacity  = JOB_RING_CAPACITY;

    // Upload backlog (brief lock)
    {
        std::unique_lock<std::mutex> ulk(m_uploadMtx);
        s.uploadBacklog = (int)m_uploadQueue.size();
    }

    // Chunk counts (brief shared lock)
    {
        std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);
        s.loadedChunks    = (int)m_chunks.size();
        s.submittedChunks = (int)m_submitted.size();
    }

    // Remaining unsubmitted candidates (GL-thread-only state — no lock needed)
    int remaining   = (int)m_pendingCandidates.size() - (int)m_candidateIdx;
    s.pendingChunks = (remaining > 0) ? remaining : 0;

    s.workerCount    = (int)m_workers.size();
    s.retryQueueSize = m_retryQueueSize.load(std::memory_order_relaxed);
    s.overflowTotal  = m_overflowCount.load(std::memory_order_relaxed);
    s.visibleDraws   = m_lastVisibleDraws;
    s.camCX          = (m_lastCamCX == INT_MIN) ? 0 : m_lastCamCX;
    s.camCZ          = (m_lastCamCZ == INT_MIN) ? 0 : m_lastCamCZ;

    // Chunk completeness diagnostics (v14)
    s.totalInRadius         = m_lastTotalInRadius;
    s.missingChunks         = m_lastMissingCount;
    s.candidateRebuildCount = m_candidateRebuildCount;
    s.strandedChunks        = m_lastStrandedCount;
    s.candidateIdx          = (int)m_candidateIdx;

    // MegaBuffer (non-const methods — OK, getDebugStats is non-const)
    s.megaUsedFaces  = m_mega.usedFaces();
    s.megaTotalFaces = m_mega.totalFaces();

    return s;
}
