#include <jni.h>
#include <GLES3/gl3.h>
#include <android/log.h>
#include <ctime>
#include <memory>
#include <cstring>
#include "core/Renderer.h"

#define TAG  "VoxelJNI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)

static std::unique_ptr<Renderer> g_renderer;

static long long getTimeNs() {
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec * 1000000000LL + ts.tv_nsec;
}
static long long g_lastTimeNs = 0;
static float getDeltaTime() {
    long long now = getTimeNs();
    if (g_lastTimeNs == 0) { g_lastTimeNs = now; return 0.016f; }
    float dt = (float)((now - g_lastTimeNs) * 1e-9);
    g_lastTimeNs = now;
    return (dt > 0.1f) ? 0.1f : dt;
}

extern "C" {

JNIEXPORT void JNICALL
Java_com_voxelgame_GameRenderer_nativeInit(JNIEnv*, jobject) {
    LOGI("nativeInit"); g_lastTimeNs = 0;
    g_renderer = std::make_unique<Renderer>(); g_renderer->init();
}
JNIEXPORT void JNICALL
Java_com_voxelgame_GameRenderer_nativeResize(JNIEnv*, jobject, jint w, jint h) {
    if (g_renderer) g_renderer->resize(w, h);
}
JNIEXPORT void JNICALL
Java_com_voxelgame_GameRenderer_nativeRender(JNIEnv*, jobject) {
    if (g_renderer) g_renderer->render(getDeltaTime());
}
JNIEXPORT void JNICALL
Java_com_voxelgame_GameSurfaceView_nativeSetMovement(JNIEnv*, jobject, jfloat x, jfloat y) {
    if (g_renderer) g_renderer->camera.setMovement(x, y);
}
JNIEXPORT void JNICALL
Java_com_voxelgame_GameSurfaceView_nativeSetLook(JNIEnv*, jobject, jfloat dx, jfloat dy) {
    if (g_renderer) g_renderer->camera.setLookDelta(dx, dy);
}
JNIEXPORT void JNICALL
Java_com_voxelgame_GameSurfaceView_nativeJump(JNIEnv*, jobject) {
    if (g_renderer) g_renderer->camera.jumpRequested.store(true);
}
JNIEXPORT void JNICALL
Java_com_voxelgame_GameSurfaceView_nativeToggleFly(JNIEnv*, jobject) {
    if (g_renderer) g_renderer->camera.flyToggleRequested.store(true);
}

// Runtime render distance — console command path ("/rd 32", "/renderdistance 16", etc.)
JNIEXPORT void JNICALL
Java_com_voxelgame_GameSurfaceView_nativeSendCommand(JNIEnv* env, jobject, jstring jcmd) {
    if (!g_renderer || !jcmd) return;
    const char* cmd = env->GetStringUTFChars(jcmd, nullptr);
    if (cmd) {
        bool ok = g_renderer->sendCommand(cmd);
        LOGI("Command \"%s\" -> %s", cmd, ok ? "OK" : "unrecognised");
        env->ReleaseStringUTFChars(jcmd, cmd);
    }
}

// Direct numeric set — Java SeekBar or EditText int field
JNIEXPORT void JNICALL
Java_com_voxelgame_GameSurfaceView_nativeSetRenderDistance(JNIEnv*, jobject, jint dist) {
    if (g_renderer) g_renderer->world.renderDistance().setDistance((int)dist);
}

// Query current value — Java UI read
JNIEXPORT jint JNICALL
Java_com_voxelgame_GameSurfaceView_nativeGetRenderDistance(JNIEnv*, jobject) {
    if (!g_renderer) return 7;
    return (jint)g_renderer->world.renderDistance().getDistance();
}

// ── Debug overlay ─────────────────────────────────────────────────────────────

// Toggle main debug panel (tap on DBG button)
JNIEXPORT void JNICALL
Java_com_voxelgame_GameSurfaceView_nativeToggleDebug(JNIEnv*, jobject) {
    if (g_renderer) g_renderer->debugOverlay().toggleDebug();
}

// Toggle advanced stats (long-press on DBG button)
JNIEXPORT void JNICALL
Java_com_voxelgame_GameSurfaceView_nativeToggleAdvancedDebug(JNIEnv*, jobject) {
    if (g_renderer) g_renderer->debugOverlay().toggleAdvanced();
}

// Query visibility for Java UI sync
JNIEXPORT jboolean JNICALL
Java_com_voxelgame_GameSurfaceView_nativeIsDebugVisible(JNIEnv*, jobject) {
    if (!g_renderer) return JNI_FALSE;
    return g_renderer->debugOverlay().isVisible() ? JNI_TRUE : JNI_FALSE;
}

// Returns a formatted multi-line stats string for the Java text overlay.
// Called every 250 ms from a Handler on the main thread — NOT on the GL thread.
// The DebugOverlay stats cache is protected by a mutex; reads are safe here.
//
// PackedFace = 2 × uint32_t = 8 bytes; used for MB calculation.
JNIEXPORT jstring JNICALL
Java_com_voxelgame_GameSurfaceView_nativeGetDebugStats(JNIEnv* env, jobject) {
    if (!g_renderer) return env->NewStringUTF("(renderer not ready)");

    // Read from the cache filled by Renderer::render() on the GL thread.
    // If the overlay was just opened the cache might hold default-zero values
    // for one polling cycle — that's acceptable.
    WorldDebugStats s = g_renderer->debugOverlay().getStats();

    // MegaBuffer memory in MB (PackedFace = 8 bytes)
    float megaUsedMB  = (float)s.megaUsedFaces  * 8.f / (1024.f * 1024.f);
    float megaTotalMB = (float)s.megaTotalFaces  * 8.f / (1024.f * 1024.f);

    char buf[2048];
    snprintf(buf, sizeof(buf),
        // ── Rendering ──────────────────────────────────────────────
        "[ RENDERING ]\n"
        "FPS          %.1f\n"
        "RD req/eff   %d / %d\n"
        "Visible      %d draws\n"
        "\n"
        // ── Streaming ──────────────────────────────────────────────
        "[ STREAMING ]\n"
        "Loaded       %d chunks\n"
        "Pending      %d chunks\n"
        "Submitted    %d\n"
        "Upload Q     %d backlog\n"
        "Workers      %d\n"
        "\n"
        // ── Thermal ────────────────────────────────────────────────
        "[ THERMAL ]\n"
        "State        %s\n"
        "Scale        %.2f  (no radius effect)\n"
        "Pressure     %.0f%%\n"
        "EMA          %.1f ms\n"
        "\n"
        // ── Queue ──────────────────────────────────────────────────
        "[ QUEUE ]\n"
        "Size         %u / %u\n"
        "Free         %u\n"
        "Retry Q      %d\n"
        "Overflows    %d\n"
        "\n"
        // ── Memory ─────────────────────────────────────────────────
        "[ MEMORY ]\n"
        "Mega         %.1f / %.1f MB\n"
        "Mega faces   %u / %u\n"
        "\n"
        // ── Position ───────────────────────────────────────────────
        "[ POSITION ]\n"
        "Chunk        (%d, %d)",
        // Rendering
        s.fps,
        s.requestedRD, s.effectiveRadius,
        s.visibleDraws,
        // Streaming
        s.loadedChunks, s.pendingChunks, s.submittedChunks,
        s.uploadBacklog, s.workerCount,
        // Thermal
        s.thermalState,
        s.thermalScale,
        s.thermalPressure * 100.f,
        s.thermalEmaMs,
        // Queue
        s.queueSize, s.queueCapacity,
        s.queueFree,
        s.retryQueueSize, s.overflowTotal,
        // Memory
        megaUsedMB, megaTotalMB,
        s.megaUsedFaces, s.megaTotalFaces,
        // Position
        s.camCX, s.camCZ
    );
    return env->NewStringUTF(buf);
}

} // extern "C"
